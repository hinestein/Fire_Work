# Data Import and Wrangling


District_sf_Transformed <- read_sf("District_sf_Transformed.shp")
Brigade_sf_Transformed <- read_sf("Brigade_sf_Transformed.shp")
Region_sf_Transformed <- read_sf("Region_sf_Transformed.shp")
Operational_Members_sf_Transformed <- read_sf("Operational_Members_sf_Transformed.shp")

Brigade_sf_Transformed <- st_simplify(Brigade_sf_Transformed, dTolerance = 100, preserveTopology = TRUE)
District_sf_Transformed <- st_simplify(District_sf_Transformed, dTolerance = 100, preserveTopology = TRUE)
Region_sf_Transformed <- st_simplify(Region_sf_Transformed, dTolerance = 100, preserveTopology = TRUE)

FRV_sf_Transformed = read_sf("FRV_sf_Transformed.shp")

FRV_District_sf_Transformed = read_sf("FRV_District_sf_Transformed.shp")

overlap = st_intersects(FRV_sf_Transformed)[[2]]



District_sf_Transformed$DISTRICT = District_sf_Transformed$DISTRIC

#Data Import

Vic_Brig_DF = read_excel("Vic_Brig_DF.xlsx")

Assets_Fleet = read_excel("Assets_Fleet.xlsx")
Assets_Buildings = read_excel("Assets_Buildings.xlsx")
Assets_PPE = read_excel("Assets_PPE.xlsx")
Asset_Plan_Fleet = read_excel("Asset_Plan_Fleet.xlsx")
Asset_Building_Plan = read_excel("Asset_Building_Plan.xlsx")

Incidents_Most_Recent = read_excel("Incidents_Most_Recent.xlsx")

Satisfaction_DF_Ordered = read_excel("Satisfaction_DF_Ordered.xlsx")

FIRS = read.csv("FIRS_Past_5_Years.csv")

Satellite_Brigade = read_excel("Satellite_Brigade")

### Variable Pre-defining
Regions = unique(Vic_Brig_DF$REGION)
Districts = unique(Vic_Brig_DF$DISTRICT)
Brigade = unique(Vic_Brig_DF$`BRIGADE NAME`)
Brigade_Numbers = unique(Vic_Brig_DF$Brigade)
Years = unique(Vic_Brig_DF$Year)











Vic_Brig_Unique = unique(Vic_Brig_DF %>% dplyr::select(Brigade, Name, X, Y, `BRIGADE NAME`, `Brigade Environment`, Average_Speed,
                                                       `SDS Turnout Time (Secs)`))

Distance_Matrix = as.matrix(dist(Vic_Brig_Unique %>% dplyr::select(X, Y)))


colnames(Distance_Matrix) = Vic_Brig_Unique$Brigade

Distance_List = list()
k = 1
for(i in 1:nrow(Distance_Matrix)){
  O1 = order(Distance_Matrix[i,])[2:31]
  Dist_Numbers = names(Distance_Matrix[i,O1])
  Current_Coord = Vic_Brig_Unique[i,] %>% dplyr::select(X, Y)
  Neigh_Distances = Distance_Matrix[i,O1]
  Temp_DF = NULL
  for(j in 1:length(Dist_Numbers)){
    Temp_Coord = (Vic_Brig_Unique %>% filter(Brigade == Dist_Numbers[j]) %>% dplyr::select(X, Y, `BRIGADE NAME`, `Brigade Environment`, Average_Speed,
                                                                                           `SDS Turnout Time (Secs)`))[1,]
    Temp_DF_1 = data.frame(Current_Brigade = Vic_Brig_Unique$Brigade[i], Neighbour = Dist_Numbers[j],
                           Index = j, Distance_Away = round(distCosine(rbind(Current_Coord, Temp_Coord %>% dplyr::select(X, Y)))/1000, 2),
                           New_X = as.numeric(Temp_Coord[1]), New_Y = as.numeric(Temp_Coord[2]),
                           Average_Speed = Temp_Coord$Average_Speed, SDS = Temp_Coord$`SDS Turnout Time (Secs)`)
    Temp_Info = paste("<b>Brigade Number:</b>", Temp_DF_1$Neighbour, "<br/>",
                      "<b>Brigade Name:</b>", Temp_Coord$`BRIGADE NAME`, "<br/>",
                      "<b>Brigade Environment:</b>", Temp_Coord$`Brigade Environment`, "<br/>",
                      "<b>Distance Away:</b>", Temp_DF_1$Distance_Away, "km", "<br/>",
                      "<b>Distance Rank:</b>", j, "<br/>",
                      "<b>SDS Turnout Time</b>:", Temp_DF_1$SDS)
    Temp_DF_1$Info = Temp_Info
    Temp_DF = rbind(Temp_DF, Temp_DF_1)
  }
  Distance_List[[k]] = unique(Temp_DF)[1:20,]
  k = k + 1
}


