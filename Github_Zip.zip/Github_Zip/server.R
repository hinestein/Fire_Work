function(input, output, session) {
  
  # Update Selection Input for District based on selected Region ----
  
  updateSelectizeInput(session = session,
                    inputId = "Brigade",
                    label = "Brigade",
                    choices = sort(Brigade),
                    selected = "",
                    
                    server = TRUE)
  
  updateSelectizeInput(session = session,
                       inputId = "District",
                       label = "District",
                       choices = sort(Districts),
                       selected = "",
                       
                       server = TRUE)
  
  updateSelectizeInput(session = session,
                       inputId = "Region",
                       label = "Region",
                       choices = sort(Regions),
                       selected = "",
                       
                       server = TRUE)
  
  observeEvent(input$Region, {
    
    District_Choices = unique(Vic_Brig_DF %>% filter(REGION == input$Region) %>% dplyr::select(DISTRICT))
    Brigade_Choices = unique(Vic_Brig_DF %>% filter(REGION == input$Region) %>% dplyr::select(DISTRICT))
    
    if(input$District == "" & input$Brigade == ""){
      updateSelectizeInput(session = session, 
                        inputId ="District",
                        label = "District",
                        choices = sort((Vic_Brig_DF %>% filter(REGION == input$Region))$DISTRICT),
                        selected = ""
      )
      updateSelectizeInput(session = session, 
                        inputId ="Brigade",
                        label = "Brigade",
                        choices = sort((Vic_Brig_DF %>% filter(REGION == input$Region) %>% dplyr::select(`BRIGADE NAME`))$`BRIGADE NAME`),
                        selected = ""
      )
    }else if(input$District != "" & input$Brigade == ""){
      updateSelectizeInput(session = session, 
                        inputId ="District",
                        label = "District",
                        choices = sort(unique(Vic_Brig_DF %>%
                                                      filter(REGION == input$Region))$DISTRICT),
                        selected = input$District
      )
      updateSelectizeInput(session = session, 
                        inputId ="Brigade",
                        label = "Brigade",
                        choices = sort(unique(Vic_Brig_DF %>% filter(DISTRICT == input$District) %>% dplyr::select(`BRIGADE NAME`))$`BRIGADE NAME`),
                        selected = ""
      )
    }else if(input$District == "" & input$Brigade != ""){
      updateSelectizeInput(session = session, 
                        inputId ="District",
                        label = "District",
                        choices = sort(unique(Vic_Brig_DF %>%
                                                      filter(REGION == input$Region))$DISTRICT),
                        selected = input$District
      )
      updateSelectizeInput(session = session, 
                        inputId ="Brigade",
                        label = "Brigade",
                        choices = sort(unique(Vic_Brig_DF %>% filter(DISTRICT == input$District) %>% dplyr::select(`BRIGADE NAME`))$`BRIGADE NAME`),
                        selected = input$Brigade
      )
    }else if(input$Region == ""){
      updateSelectizeInput(session = session, 
                        inputId ="District",
                        label = "District",
                        choices = sort(Districts),
                        selected = ""
      )
      updateSelectizeInput(session = session, 
                        inputId ="Brigade",
                        label = "Brigade",
                        choices = sort(Brigade),
                        selected = ""
      )
    }
    
    
    
    
    
  })
  
  # Update Selection Input for Brigade based on selected District ----
  
  observeEvent(input$District, {
    if(input$Brigade == ""){
      updateSelectizeInput(session = session, 
                        inputId ="Brigade",
                        label = "Brigade",
                        choices = sort(unique(Vic_Brig_DF %>%
                                                      filter(DISTRICT == input$District) %>%
                                                      dplyr::select(`BRIGADE NAME`))$`BRIGADE NAME`
                        ),
                        selected = ""
                        
      )
    }else{
      updateSelectizeInput(session = session, 
                        inputId ="Brigade",
                        label = "Brigade",
                        choices = sort(unique(Vic_Brig_DF %>%
                                                      filter(DISTRICT == input$District) %>%
                                                      dplyr::select(`BRIGADE NAME`))$`BRIGADE NAME`
                        ),
                        selected = input$Brigade
                        
      )
    }
    
    if(input$Region == ""){
      updateSelectizeInput(session = session, 
                        inputId = "Region",
                        label = "Region",
                        choices = sort(Regions),
                        selected = unique(Vic_Brig_DF %>%
                                            filter(DISTRICT == input$District) %>%
                                            dplyr::select(REGION))$REGION
                        
      )
    }
    
  })
  
  
  observeEvent(input$Brigade, {
    if(input$District == "" & input$Region == "" & input$Brigade != ""){
      
      Brigade_Region_input = unique(Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(REGION))$REGION
      
      
      updateSelectizeInput(session = session, 
                        inputId ="District",
                        label = "District",
                        choices = c("", sort(unique(Vic_Brig_DF %>%
                                                      filter(REGION == Brigade_Region_input) %>%
                                                      dplyr::select(DISTRICT))$DISTRICT)
                        ),
                        selected = unique(Vic_Brig_DF %>%
                                            filter(`BRIGADE NAME` == input$Brigade) %>%
                                            dplyr::select(DISTRICT))$DISTRICT
                        
                        
                        
      )
      
      updateSelectizeInput(session = session, 
                        inputId ="Region",
                        label = "Region",
                        choices = c("", sort(Regions)
                        ),
                        selected = Brigade_Region_input
      )
    }else if(input$District == "" & input$Region != "" & input$Brigade != ""){
      Brigade_Region_input = unique(Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(REGION))$REGION
      
      
      updateSelectizeInput(session = session, 
                        inputId ="District",
                        label = "District",
                        choices = c("", sort(unique(Vic_Brig_DF %>%
                                                      filter(REGION == Brigade_Region_input) %>%
                                                      dplyr::select(DISTRICT))$DISTRICT)
                        ),
                        selected = unique(Vic_Brig_DF %>%
                                            filter(`BRIGADE NAME` == input$Brigade) %>%
                                            dplyr::select(DISTRICT))$DISTRICT
      )
    }
    
    
  })
  
 
  
  
  
  
  observeEvent(input$Brigade,{
    
    Incidents = (Incidents_Most_Recent %>% filter(Name == input$Brigade) %>% dplyr::select(`Yearly Avg Structure Incidents 2017 to 2021`))[1,1]
    
    
    Brig_Environment_Speed = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>% dplyr::select(`Brigade Environment`))[1,1]
    
    Pop = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>%
         dplyr::select(Population))[1,1]
    
    Density = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>%
         dplyr::select(BUA_P))[1,1]
    
    
    
    
    
    if(input$Brigade != ""){
      updateSliderInput(session = session, 
                        inputId ="Incidents",
                        label = "Incidents",
                        value = floor(as.numeric(Incidents)),
                        min = 0,
                        max = 60
      )
      updateSliderInput(session = session,
                        inputId = "Population",
                        label = "Population",
                        value = as.numeric(Pop),
                        min = 0,
                        max = 100000)
      updateNumericInput(session = session,
                         inputId = "Density",
                         label = "Density",
                         value = round(as.numeric(Density), 3),
                         min = 0,
                         max = 100, step = 0.01)
      L_Use_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Land Use`))[1,1]
      
      updateSelectizeInput(session = session, 
                        inputId ="LandUse",
                        label = "Land Use",
                        choices = c("Grassfire", "Bushfire"),
                        selected = L_Use_Current
      )
      
      
    }
    
  })
  
  
  
  observeEvent(input$Year,{
    
    Incidents = (Incidents_Most_Recent %>% filter(Name == input$Brigade) %>% dplyr::select(`Yearly Avg Structure Incidents 2017 to 2021`))[1,1]
    
    
    Brig_Environment_Speed = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>% dplyr::select(`Brigade Environment`))[1,1]
    
    Pop = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>%
             dplyr::select(Population))[1,1]
    
    Density = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>%
                 dplyr::select(BUA_P))[1,1]
    
    
    
    
    
    if(input$Brigade != ""){
      updateSliderInput(session = session, 
                        inputId ="Incidents",
                        label = "Incidents",
                        value = floor(as.numeric(Incidents)),
                        min = 0,
                        max = 60
      )
      updateSliderInput(session = session,
                        inputId = "Population",
                        label = "Population",
                        value = as.numeric(Pop),
                        min = 0,
                        max = 100000)
      updateNumericInput(session = session,
                         inputId = "Density",
                         label = "Density",
                         value = round(as.numeric(Density), 3),
                         min = 0,
                         max = 100, step = 0.01)
      L_Use_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Land Use`))[1,1]
      
      updateSelectizeInput(session = session, 
                           inputId ="LandUse",
                           label = "Land Use",
                           choices = c("Grassfire", "Bushfire"),
                           selected = L_Use_Current
      )
    
      
    }
    
  })
  
  
  
  Current_Year = as.numeric(format(Sys.Date(), "%Y"))
  
  
  
  
  observeEvent(input$MapType,{
    if(input$MapType == "Region" & !input$Focus){
      if(input$MapFeatures == "Built Up Area"){
        updateSelectizeInput(session = session,
                             inputId = "MapFeatures",
                          label = "Feature",
                          choices = c("Choose Feature",
                                      "Member Locations",
                                      "Asset Status",
                                      "Brigade Environment",
                                      "Population",
                                      "Member Numbers"),
                          selected = "Choose Feature")
      }else{
        updateSelectizeInput(session = session,
                             inputId = "MapFeatures",
                          label = "Feature",
                          choices = c("Choose Feature",
                                      "Member Locations",
                                      "Asset Status",
                                      "Brigade Environment",
                                      "Population",
                                      "Member Numbers"),
                          selected = input$MapFeatures)
      }
      
    }else if(input$MapType == "District" & !input$Focus){
      if(input$MapFeatures == "Built Up Area"){
        updateSelectizeInput(session = session,
          inputId = "MapFeatures",
                          label = "Feature",
                          choices = c("Choose Feature",
                                      "Member Locations",
                                      "Asset Status",
                                      "Brigade Environment",
                                      "Population",
                                      "Member Numbers"),
                          selected = "Choose Feature")
      }else{
        updateSelectizeInput(session = session,
          inputId = "MapFeatures",
                          label = "Feature",
                          choices = c("Choose Feature",
                                      "Member Locations",
                                      "Asset Status",
                                      "Brigade Environment",
                                      "Population",
                                      "Member Numbers"),
                          selected = input$MapFeatures)
      }
    }else if(input$MapType == "Brigade" & !input$Focus){
      updateSelectizeInput(session = session,
        inputId = "MapFeatures",
                        label = "Feature",
                        choices = c("Choose Feature",
                                    "Member Locations",
                                    "Asset Status",
                                    "Brigade Environment",
                                    "Population",
                                    "Built Up Area",
                                    "Member Numbers"),
                        selected = input$MapFeatures)
    }else if(input$Focus){
      updateSelectizeInput(session = session,
        inputId = "MapFeatures",
                        label = "Feature",
                        choices = c("Choose Feature",
                                    "Member Locations",
                                    "SDS"),
                        selected = "Choose Feature")
    }
  })
  
  observeEvent(input$Focus, {
    if(input$MapType == "Region" & !input$Focus){
      if(input$MapFeatures == "Built Up Area"){
        updateSelectizeInput(session = session,
                             inputId = "MapFeatures",
                             label = "Feature",
                             choices = c("Choose Feature",
                                         "Member Locations",
                                         "Asset Status",
                                         "Brigade Environment",
                                         "Population",
                                         "Member Numbers"),
                             selected = "Choose Feature")
      }else{
        updateSelectizeInput(session = session,
                             inputId = "MapFeatures",
                             label = "Feature",
                             choices = c("Choose Feature",
                                         "Member Locations",
                                         "Asset Status",
                                         "Brigade Environment",
                                         "Population",
                                         "Member Numbers"),
                             selected = input$MapFeatures)
      }
      
    }else if(input$MapType == "District" & !input$Focus){
      if(input$MapFeatures == "Built Up Area"){
        updateSelectizeInput(session = session,
                             inputId = "MapFeatures",
                             label = "Feature",
                             choices = c("Choose Feature",
                                         "Member Locations",
                                         "Asset Status",
                                         "Brigade Environment",
                                         "Population",
                                         "Member Numbers"),
                             selected = "Choose Feature")
      }else{
        updateSelectizeInput(session = session,
                             inputId = "MapFeatures",
                             label = "Feature",
                             choices = c("Choose Feature",
                                         "Member Locations",
                                         "Asset Status",
                                         "Brigade Environment",
                                         "Population",
                                         "Member Numbers"),
                             selected = input$MapFeatures)
      }
    }else if(input$MapType == "Brigade" & !input$Focus){
      updateSelectizeInput(session = session,
                           inputId = "MapFeatures",
                           label = "Feature",
                           choices = c("Choose Feature",
                                       "Member Locations",
                                       "Asset Status",
                                       "Brigade Environment",
                                       "Population",
                                       "Built Up Area",
                                       "Member Numbers"),
                           selected = input$MapFeatures)
    }else if(input$Focus){
      updateSelectizeInput(session = session,
                           inputId = "MapFeatures",
                           label = "Feature",
                           choices = c("Choose Feature",
                                       "Member Locations",
                                       "SDS"),
                           selected = "Choose Feature")
    }
  })
  

  
  
  # Output plot based on shapefile ----
  
  output$mapPlot <- renderLeaflet({
    X_Coord = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(X))[1,1]
    Y_Coord = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Y))[1,1]
    Brigade_Number_Current = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(`Brigade Number`))[1,1]
    Brigade_Suburb = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Suburb))[1,1]
    Brigade_Postcode = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Postcode))[1,1]
    
    Brigade_Location = data.frame(X = X_Coord, Y = Y_Coord,
                                  info = paste("<b>Brigade Number:</b>", Brigade_Number_Current, "<br/>",
                                               "<b>Suburb:</b>", Brigade_Suburb, "<br/>",
                                               "<b>Postcode:</b>", Brigade_Postcode))
    
    Brig_Environment_Speed = (Vic_Brig_DF %>%
                                filter(`BRIGADE NAME` == input$Brigade & Year == Current_Year) %>%
                                dplyr::select(Average_Speed))[1,1]
    
    
    Start_Speed = Brig_Environment_Speed$Average_Speed[1]
    
    
    SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade& Year == Current_Year) %>%
                     dplyr::select(`SDS Turnout Time (Secs)`))[1,1])
    
    SDS_District = (Vic_Brig_DF %>% filter(DISTRICT == input$District & Year == Current_Year) %>%
                      dplyr::select(`SDS Turnout Time (Secs)`))[,1]
    
    SDS_Region = (Vic_Brig_DF %>% filter(REGION == input$Region & Year == Current_Year) %>%
                    dplyr::select(`SDS Turnout Time (Secs)`))[,1]
    
    Region_Average = ((Vic_Brig_DF %>% filter(REGION == input$Region & Year == Current_Year) %>%
                     dplyr::select(Average_Speed))[,1])$Average_Speed
    
    District_Average = ((Vic_Brig_DF %>% filter(DISTRICT == input$District & Year == Current_Year) %>%
                       dplyr::select(Average_Speed))[,1])$Average_Speed
    
    
    
    
    
    ## Region Plot ----
    
    
    if(input$MapType == "Region"){
      if(input$Focus){
        if(input$MapFeaturesFocus == "Choose Feature"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, popup = ~Info) %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1,
                        group = "Brigade Boundaries", popup = ~Info) %>%
            addPolygons(data = District_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1,
                        group = "District Boundaries", popup = ~Info) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info) %>%
              addLayersControl(overlayGroups = c("District Boundaries", "Brigade Boundaries")) %>%
            hideGroup(c("District Boundaries", "Brigade Boundaries"))
        }else if(input$MapFeaturesFocus == "SDS"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info) %>%
            addCircles(lng = ((Vic_Brig_DF %>% filter(REGION == input$Region) %>% dplyr::select(X))[,1])$X,
                       lat = ((Vic_Brig_DF %>% filter(REGION == input$Region) %>% dplyr::select(Y))[,1])$Y, 
                       radius = (SDS_Region * Region_Average)[,1], group = "Low Traffic") %>%
            addPolygons(data = District_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, group = "District Boundaries") %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, group = "Brigade Boundaries")
        }else if(input$MapFeaturesFocus == "Member Locations"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info) %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(REGION == input$Region),
                        fillColor = ~pal_bin_Region_Members(Join_Count), fillOpacity = 0.8,
                        color = ~pal_bin_Region_Members(Join_Count), opacity = 1,
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Region") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(DISTRICT == input$District),
                        fillColor = ~pal_bin_Region_Members(Join_Count),
                        color = ~pal_bin_Region_Members(Join_Count),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "District") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(brig_name == input$Brigade),
                        fillColor = ~pal_bin_Region_Members(Join_Count),
                        color = ~pal_bin_Region_Members(Join_Count),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Brigade") %>%
            addPolygons(data = District_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, group = "District Boundaries") %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, group = "Brigade Boundaries") %>%
            addLayersControl(baseGroups = c("Region", "District", "Brigade"),
                             overlayGroups = c("Brigade Boundaries", "District Boundaries"))
        }
        
        
        
        
        
        
      }else{
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed, 
                        fillOpacity = 0.02,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info) %>% 
            addPolygons(data = Operational_Members_sf_Transformed,
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "All") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(REGION == input$Region),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Region") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(DISTRICT == input$District),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "District") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(brig_name == input$Brigade),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Region") %>% 
            addLayersControl(
              baseGroups = c("All", "Region", "District", "Brigade")
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Choose Feature"){
          if(input$Brigade == ""){
            leaflet() %>%
              addTiles() %>%
              addPolygons(data = Region_sf_Transformed, 
                          fillOpacity = 0.02, color = "black", weight = 1, opacity = 1, popup = ~Info)
          }else{
            leaflet() %>%
              addTiles() %>%
              addPolygons(data = Region_sf_Transformed, 
                          fillOpacity = 0.02, color = "black", weight = 1, opacity = 1, popup = ~Info) %>%
              addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
          }
        }else if(input$MapFeatures == "Asset Status"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Assets_Region(Asset),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Ass, group = "Asset") %>% 
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Assets_Region(Fleet),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Flt, group = "Fleet") %>% 
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Assets_Region(Buildng),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Bld, group = "Building")%>% 
            addLegend(pal = pal_bin_Assets_Region,
                      values = range(c(Region_sf_Transformed$Fleet,
                                       Region_sf_Transformed$Buildng,
                                       Region_sf_Transformed$Asset), na.rm = TRUE),
                      opacity = 1,
                      title = "Brigade Asset<br/>Satisfaction<br/>Percentage")  %>%
            addLayersControl(
              baseGroups = c("Asset", "Fleet", "Building"),
              options = layersControlOptions(collapsed = FALSE)
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Brigade Environment"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Environment_Region(Agrcltr),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Agr, group = "Agricultural & Natural Environment") %>% 
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Environment_Region(Hybrid),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Hyb, group = "Hybrid") %>% 
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Environment_Region(Strct_1),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_S_1, group = "Structure 1")  %>% 
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Environment_Region(Strct_2),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_S_2, group = "Structure 2")   %>% 
            addLegend(pal = pal_bin_Environment_Region,
                      values = range(c(Region_sf_Transformed$Agrcltr,
                                       Region_sf_Transformed$Hybrid,
                                       Region_sf_Transformed$Strct_1,
                                       Region_sf_Transformed$Strct_2), na.rm = TRUE),
                      opacity = 1,
                      title = "Brigade Environment<br/>Percentage")  %>%
            addLayersControl(
              baseGroups = c("Agricultural &<br/> Natural Environment", "Hybrid", "Structure 1", "Structure 2"),
              options = layersControlOptions(collapsed = FALSE)
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Population"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Region_Population(Popultn),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "Population") %>% 
            addLegend(pal = pal_bin_Region_Population,
                      values = range(as.numeric(Region_sf_Transformed$Popultn), na.rm = TRUE),
                      opacity = 1, group = "Population", layerId = "Population") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Member Numbers"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Region_sf_Transformed,
                        fillColor = ~pal_bin_Region_Member_Numbers(Members),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "Members") %>% 
            addLegend(pal = pal_bin_Region_Member_Numbers,
                      values = range(as.numeric(Region_sf_Transformed$Members), na.rm = TRUE),
                      opacity = 1, group = "Members", layerId = "Members", title = "Number of<br/>Members") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }
      
      
      ## District Plot ----
      
    }else if(input$MapType == "District"){
      if(input$Focus){
        if(input$MapFeaturesFocus == "Member Locations"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed %>% filter(DISTRIC == input$District),
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, popup = ~Info) %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(DISTRCT == input$District), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, group = "Brigade Boundaries") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info) %>%
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(DISTRICT == input$District),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "District") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(brig_name == input$Brigade),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Brigade") %>%
            addLayersControl(baseGroups = c("District", "Brigade"),
                             overlayGroups = c("Brigade Boundaries"))
        }else if(input$MapFeaturesFocus == "SDS"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed %>% filter(DISTRIC == input$District), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info) %>%
            addCircles(lng = ((Vic_Brig_DF %>% filter(DISTRICT == input$District) %>% dplyr::select(X))[,1])$X,
                       lat = ((Vic_Brig_DF %>% filter(DISTRICT == input$District) %>% dplyr::select(Y))[,1])$Y, 
                       radius = (SDS_District * District_Average)[,1]) %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(DISTRCT == input$District), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, group = "Brigade Boundaries")
        }else if(input$MapFeaturesFocus == "Choose Feature"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed %>% filter(DISTRIC == input$District), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1, popup = ~Info) %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(DISTRCT == input$District), 
                        fillOpacity = 0.02, color = "black", weight = 2, opacity = 1,
                        group = "Brigade Boundaries", popup = ~Info) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info) %>%
            addLayersControl(overlayGroups = c("Brigade Boundaries")) %>%
            hideGroup(c("Brigade Boundaries"))
        }
        
        
        
        
      }else{
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed, 
                        fillOpacity = 0.02,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info) %>% 
            addPolygons(data = Operational_Members_sf_Transformed,
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "All") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(REGION == input$Region),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Region") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(DISTRICT == input$District),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "District") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(brig_name == input$Brigade),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Region") %>% 
            addLayersControl(
              baseGroups = c("All", "Region", "District", "Brigade")
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Choose Feature"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed, 
                        fillOpacity = 0.02,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info)%>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Brigade Environment"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Environment_District(Agrcltr),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Agr, group = "Agricultural & Natural Environment") %>% 
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Environment_District(Hybrid),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Hyb, group = "Hybrid") %>% 
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Environment_District(Strct_1),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_S_1, group = "Structure 1")  %>% 
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Environment_District(Strct_2),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_S_2, group = "Structure 2")   %>% 
            addLegend(pal = pal_bin_Environment_District,
                      values = range(c(District_sf_Transformed$Agrcltr,
                                       District_sf_Transformed$Hybrid,
                                       District_sf_Transformed$Strct_1,
                                       District_sf_Transformed$Strct_2), na.rm = TRUE),
                      opacity = 1,
                      title = "Brigade Environment<br/>Percentage")  %>%
            addLayersControl(
              baseGroups = c("Agricultural &<br/> Natural Environment", "Hybrid", "Structure 1", "Structure 2"),
              options = layersControlOptions(collapsed = FALSE)
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Asset Status"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Assets_District(Asset),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Ass, group = "Asset") %>% 
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Assets_District(Fleet),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Flt, group = "Fleet") %>% 
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_Assets_District(Building),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Inf_Bld, group = "Building")%>% 
            addLegend(pal = pal_bin_Assets_District,
                      values = range(c(District_sf_Transformed$Fleet,
                                       District_sf_Transformed$Building,
                                       District_sf_Transformed$Asset), na.rm = TRUE),
                      opacity = 1,
                      title = "Brigade Asset<br/>Satisfaction<br/>Percentage")  %>%
            addLayersControl(
              baseGroups = c("Asset", "Fleet", "Building"),
              options = layersControlOptions(collapsed = FALSE)
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Population"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_District_Population(Popultn),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "Population") %>% 
            addLegend(pal = pal_bin_District_Population,
                      values = range(as.numeric(District_sf_Transformed$Population), na.rm = TRUE),
                      opacity = 1, group = "Population", layerId = "Population") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else if(input$MapFeatures == "Member Numbers"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = District_sf_Transformed,
                        fillColor = ~pal_bin_District_Member_Numbers(Members),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "Members") %>% 
            addLegend(pal = pal_bin_District_Member_Numbers,
                      values = range(as.numeric(District_sf_Transformed$Members), na.rm = TRUE),
                      opacity = 1, group = "Members", layerId = "Members", title = "Number of<br/>Members") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }
      
      
      
      
      
      ## Brigade Plot ----
      
      
    }else if(input$MapType == "Brigade"){
      
      Satellite = Satellite_Brigade %>% filter(`BRIGADE NUM` == as.numeric(Brigade_Number_Current))
      Satellite$Info = paste(Satellite$`BRIGADE NAME`, "Satellite")
      
      
      if(input$Focus){
        if(input$MapFeaturesFocus == "Choose Feature"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                        fillOpacity = 0.02, color = "black", weight = 1, opacity = 1, popup = ~Info) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
            
        }else if(input$MapFeaturesFocus == "SDS"){
          if(nrow(Satellite) == 0){
            leaflet() %>%
              addTiles() %>%
              clearGroup(group = "Neighbours") %>%
              clearGroup(group = "NewMarker") %>%
              addPolygons(data = Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                          fill = FALSE, color = "black", weight = 1, opacity = 1, popup = ~Info) %>%
              addMarkers(data = Brigade_Location, ~X, ~Y, group = "BrigadeLocation", popup = ~info)%>%
              addPolygons()
              addCircles(lng = as.numeric(X_Coord),
                         lat = as.numeric(Y_Coord), 
                         radius = Start_Speed * SDS_Brigade,
                         group= "SDS")
          }else{
            leaflet() %>%
              addTiles() %>%
              clearGroup(group = "Neighbours") %>%
              clearGroup(group = "NewMarker") %>%
              addPolygons(data = Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                          fill = FALSE, color = "black", weight = 1, opacity = 1, popup = ~Info) %>%
              addMarkers(data = Brigade_Location, ~X, ~Y, group = "BrigadeLocation", popup = ~info)%>%
              addCircles(lng = as.numeric(X_Coord),
                         lat = as.numeric(Y_Coord), 
                         radius = Start_Speed * SDS_Brigade,
                         group= "SDS") %>%
              addMarkers(data = Satellite, lng = ~as.numeric(X), lat = ~as.numeric(Y), group = "SDS", popup = ~Info) %>%
              addCircles(data = Satellite, lng = ~as.numeric(X), lat = ~as.numeric(Y), group = "SDS",
                         radius = Start_Speed * SDS_Brigade, color = "#1FBDC6")
          }
          
            
          
        }else if(input$MapFeaturesFocus == "Member Locations"){
          pal_bin_Brigade_Member_Locations = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                                      domain = range(as.numeric((Operational_Members_sf_Transformed  %>% filter(brig_name == input$Brigade))$Join_Count), na.rm = TRUE),
                                                                                na.color = "#808080",
                                                                                bins = 5, reverse = TRUE)
          
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                        fillOpacity = 0.02, color = "black", weight = 1, opacity = 1, popup = ~Info) %>%
            addPolygons(data = Operational_Members_sf_Transformed  %>% filter(brig_name == input$Brigade),
                        fillColor = ~pal_bin_Brigade_Member_Locations(Join_Count), popup = ~paste("<b>Members:</b>", Join_Count),
                        color = ~pal_bin_Brigade_Member_Locations(Join_Count))%>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation") %>%
            addLegend(pal = pal_bin_Brigade_Member_Locations,
                      values = (Operational_Members_sf_Transformed  %>% filter(brig_name == input$Brigade))$Join_Count,
                      opacity = 1)
        }
        
        
      }else{
        if(input$MapFeatures == "Member Locations"){
          
          
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed, 
                        fillOpacity = 0.02,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info) %>% 
            addPolygons(data = Operational_Members_sf_Transformed,
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "All") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(REGION == input$Region),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Region") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(DISTRICT == input$District),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "District") %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(Brigade_No == as.numeric(Brigade_Number_Current)),
                        popup = ~paste0("<b>Members</b>: ", Join_Count),
                        group = "Brigade") %>% 
            addLayersControl(
              baseGroups = c("All", "Region", "District", "Brigade")
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
        }else if(input$MapFeatures == "Choose Feature"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed, 
                        fillOpacity = 0.02, color = "black", weight = 0.5, opacity = 1, popup = ~Info) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
        }else if(input$MapFeatures == "Asset Status"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_binary_building(factor(Buildng, levels = c("Satisfied", "Unknown", "Unsatisfied"))), 
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Inf_Bld,
                        group = "Building") %>%
            addPolygons(data = Brigade_sf_Transformed, 
                        fillColor = ~pal_binary_fleet(Fleet), 
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Inf_Flt,
                        group = "Fleet") %>%
            addPolygons(data = Brigade_sf_Transformed, 
                        fillColor = ~pal_binary_asset(Asset), 
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Inf_Ass,
                        group = "Asset") %>%
            addLegend(colors = c("#4CAB86", "#ffdb00", "#E4002b"),
                      values = ~factor(Asset, levels = c("Satisfied", "Unsatisfied", "Unknown")),
                      labels = c("Satisfied", "Unknown", "Unsatisfied"),
                      opacity = 1)%>%
            addLayersControl(
              baseGroups = c("Asset", "Fleet", "Building")
            ) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
        }else if(input$MapFeatures == "Brigade Environment"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_binary_Environment(factor(Envrnmn)),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info, group = "All") %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_binary_Environment(factor(Envrnmn)),
                        fill = Brigade_sf_Transformed$Environment == "Agricultural & Natural Environment",
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info, group = "Agricultural & Natural Environment") %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_binary_Environment(factor(Envrnmn)),
                        fill = Brigade_sf_Transformed$Environment == "Hybrid",
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info, group = "Hybrid") %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fill = Brigade_sf_Transformed$Environment == "Structural 1",
                        fillColor = ~pal_binary_Environment(factor(Envrnmn)),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info, group = "Structural 1") %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_binary_Environment(Brigade_sf_Transformed$Environment),
                        fill = Brigade_sf_Transformed$Environment == "Structural 2",
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.5, 
                        opacity = 1,
                        popup = ~Info, group = "Structural 2") %>%
            addLayersControl(
              baseGroups = c("All", "Agricultural & Natural Environment", "Hybrid", "Structural 1", "Structural 2")
            ) %>% 
            addLegend(pal = pal_binary_Environment,
                      values = c("Agricultural & <br/> Natural Environment", "Hybrid", "Structural 1", "Structural 2"),
                      opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
          
          
        }else if(input$MapFeatures == "Population"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_bin_Population(Popultn),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "Population") %>% 
            addLegend(pal = pal_bin_Population,
                      values = range(as.numeric(Brigade_sf_Transformed$Population), na.rm = TRUE),
                      opacity = 1, group = "Population", layerId = "Population") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
          
          
        }else if(input$MapFeatures == "Built Up Area"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_bin_BUA(as.numeric(BUA)),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "BUA")  %>% 
            addLegend(pal = pal_bin_BUA,
                      values = range(as.numeric(Brigade_sf_Transformed$BUA), na.rm = TRUE),
                      opacity = 1, group = "BUA",
                      layerId = "BUA") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
          
          
        }else if(input$MapFeatures == "Member Numbers"){
          leaflet() %>%
            addTiles() %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillColor = ~pal_bin_Brigade_Member_Numbers(Members),
                        fillOpacity = 0.8,
                        color = "black", 
                        weight = 0.3, 
                        opacity = 1,
                        popup = ~Info, group = "Members") %>% 
            addLegend(pal = pal_bin_Brigade_Member_Numbers,
                      values = range(as.numeric(Brigade_sf_Transformed$Members), na.rm = TRUE),
                      opacity = 1, group = "Members", layerId = "Members", title = "Number of<br/>Members") %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
        }
      }
      
    }
    
    
    
    
    
  })
  
  
  
  
  observeEvent(input$mapPlot_click, {
    if(input$MapFeaturesFocus == "SDS" & input$MapType == "Brigade"){
      click_lat <- input$mapPlot_click$lat
      click_lng <- input$mapPlot_click$lng
      
      
      X_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(X))[1,1]
      Y_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(Y))[1,1]
      
      
      SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                  dplyr::select(`SDS Turnout Time (Secs)`))[1,1])
      
      Ave_Speed = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                  dplyr::select(Average_Speed))[1,1])
      
      # Add a marker at the clicked location
      leafletProxy("mapPlot") %>%
        clearGroup(group = "NewMarker") %>%  # Optional: Clear previous markers
        addAwesomeMarkers(lng = click_lng, lat = click_lat, group = "NewMarker") %>%
        addCircles(lng = click_lng, lat = click_lat, group = "NewMarker",
                   radius = Ave_Speed * SDS_Brigade, fillColor = "#FFDB00", color = "#FFDB00")
      
      
    }
  })
  
  observeEvent(input$Neighbours, {
    if(input$MapFeaturesFocus == "SDS" & input$Neighbours > 0){
      X_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(X))[1,1]
      Y_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(Y))[1,1]
      
      SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                  dplyr::select(`SDS Turnout Time (Secs)`))[1,1])
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(`Brigade Number`))[1,1]
      
      k = which(Brigade_Numbers == as.numeric(Brigade_Number_Current))
      Neighbours = Distance_List[[k]][1:input$Neighbours,]
      
      leafletProxy("mapPlot") %>%
        clearGroup(group = "Neighbours") %>%
        addAwesomeMarkers(data = Neighbours,
          lng = as.numeric(Neighbours$New_X),
                   lat = as.numeric(Neighbours$New_Y),
                   popup = ~Neighbours$Info, group = "Neighbours") %>%
        addCircles(lng = Neighbours$New_X,
                   lat = Neighbours$New_Y,
                   fillColor = "green",
                   color = "green",
                   radius = Neighbours$Average_Speed * Neighbours$SDS, group = "Neighbours")
      

      
    }else if(input$MapFeaturesFocus == "SDS" & input$Neighbours == 0 & input$Brigade != ""){
      X_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(X))[1,1]
      Y_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(Y))[1,1]
      
      SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                  dplyr::select(`SDS Turnout Time (Secs)`))[1,1])
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(`Brigade Number`))[1,1]
      
      
      
      leafletProxy("mapPlot") %>%
        clearGroup(group = "Neighbours")
    }
  })
  
  observeEvent(input$Incidents_SDS, {
    if(input$Incidents_SDS){
      X_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(X))[1,1]
      Y_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(Y))[1,1]

      Brigade_Number_Current = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(`Brigade Number`))[1,1]
      
      SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                  dplyr::select(`SDS Turnout Time (Secs)`))[1,1])

      
      
      Incidents_SDS = FIRS %>% filter(brigade_no == as.numeric(Brigade_Number_Current))
      
      SDS_Difference = difftime(as.POSIXct(Incidents_SDS$primary_arrival_datetime,format="%Y-%m-%d %H:%M:%S"), 
                                as.POSIXct(Incidents_SDS$primary_turnout_datetime, format="%Y-%m-%d %H:%M:%S"), units = "secs") - SDS_Brigade
      
      SDS_Pass = ifelse(SDS_Difference <= 0, "Y", "N")
      
      leafletProxy("mapPlot") %>%
        clearGroup(group = "Incidents")  %>%
        addCircles(lng = as.numeric(Incidents_SDS$shape_latitude), lat = as.numeric(Incidents_SDS$shape_longitude),
                   fillOpacity = 1, opacity = 1, color = pal_factor_SDS_Pass(SDS_Pass),
                   popup = paste("<b>Incident Number:</b>", Incidents_SDS$incident_no, "<br/>",
                                 "<b>Date:</b>", ifelse(Incidents_SDS$primary_turnout_datetime, "Unknown",
                                                        as.Date(Incidents_SDS$primary_turnout_datetime)), "<br/>",
                                 "<b>Time:</b>", format(as.POSIXct(Incidents_SDS$primary_arrival_datetime,format="%Y-%m-%d %H:%M:%S"),
                                                        format = "%H:%M:%S"), "<br/>",
                                 "<b>SDS Difference:</b>", SDS_Difference, "<br/>",
                                 "<b>Incident Type:</b>", Incidents_SDS$incident_type_division, "<br/>",
                                 "<b>Suspicious Status:</b>", Incidents_SDS$incident_suspicious_status), group = "Incidents")
    }else{
      leafletProxy("mapPlot") %>%
        clearGroup(group = "Incidents")
    }
      
    
    
  })
  
  observeEvent(input$FRVDistrict, {
    if(input$FRVDistrict){
      X_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(X))[1,1]
      Y_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(Y))[1,1]
      
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(`Brigade Number`))[1,1]
      

      

      
      leafletProxy("mapPlot") %>%
        clearGroup(group = "FRVDistrict") %>%
        addPolygons(data = FRV_District_sf_Transformed, group = "FRVDistrict", color = "#5b0b30",
                    fillOpacity = 0.25)
        
    }else if(!input$FRVDistrict){
      leafletProxy("mapPlot") %>%
        clearGroup(group = "FRVDistrict")
    }
    
    
    
  })
  
  
  observeEvent(input$FRV, {
    if(input$FRV & input$Incidents_SDS){
      X_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(X))[1,1]
      Y_Coord = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(Y))[1,1]
      
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(`Brigade Number`))[1,1]
      
      SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                  dplyr::select(`SDS Turnout Time (Secs)`))[1,1])
      
      
      
      Incidents_SDS = FIRS %>% filter(brigade_no == as.numeric(Brigade_Number_Current))
      
      SDS_Difference = difftime(as.POSIXct(Incidents_SDS$primary_arrival_datetime,format="%Y-%m-%d %H:%M:%S"), 
                                as.POSIXct(Incidents_SDS$primary_turnout_datetime, format="%Y-%m-%d %H:%M:%S"), units = "secs") - SDS_Brigade
      
      SDS_Pass = ifelse(SDS_Difference <= 0, "Y", "N")
      
      inter = st_intersects(Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                                                              FRV_sf_Transformed)
      
      
      
      
      leafletProxy("mapPlot") %>%
        clearGroup(group = "FRV") %>%
        clearGroup(group = "Incidents") %>%
        addPolygons(data = FRV_sf_Transformed[inter[[1]],], group = "FRV", color = "#5b0b30",
                    fillOpacity = 0.25) %>%
        addCircles(lng = as.numeric(Incidents_SDS$shape_latitude), lat = as.numeric(Incidents_SDS$shape_longitude),
                   fillOpacity = 1, opacity = 1, color = pal_factor_SDS_Pass(SDS_Pass),
                   popup = paste("<b>Incident Number:</b>", Incidents_SDS$incident_no, "<br/>",
                                 "<b>Date:</b>", ifelse(Incidents_SDS$primary_turnout_datetime, "Unknown",
                                                        as.Date(Incidents_SDS$primary_turnout_datetime)), "<br/>",
                                 "<b>Time:</b>", format(as.POSIXct(Incidents_SDS$primary_arrival_datetime,format="%Y-%m-%d %H:%M:%S"),
                                                        format = "%H:%M:%S"), "<br/>",
                                 "<b>SDS Difference:</b>", SDS_Difference, "<br/>",
                                 "<b>Incident Type:</b>", Incidents_SDS$incident_type_division, "<br/>",
                                 "<b>Suspicious Status:</b>", Incidents_SDS$incident_suspicious_status), group = "Incidents")
      
    }else if(input$FRV & !input$Incidents_SDS){
      
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade) %>%
          dplyr::select(`Brigade Number`))[1,1]
      
      inter = st_intersects(Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                            FRV_sf_Transformed)
      
      leafletProxy("mapPlot") %>%
        clearGroup(group = "FRV") %>%
        clearGroup(group = "Incidents") %>%
        addPolygons(data = FRV_sf_Transformed[inter[[1]],], group = "FRV", color = "#5b0b30",
                    fillOpacity = 0.25)
    }else{
      leafletProxy("mapPlot") %>%
        clearGroup(group = "FRV")
    }
    
    
    
  })
  
  
  observeEvent(input$MarkerRemove,{
    leafletProxy("mapPlot") %>%
      clearGroup(group = "NewMarker")
  })
  
  observeEvent(input$Brigade,{
    X_Coord = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(X))[1,1]
    Y_Coord = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Y))[1,1]
    Brigade_Number_Current = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(`Brigade Number`))[1,1]
    Brigade_Suburb = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Suburb))[1,1]
    Brigade_Postcode = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Postcode))[1,1]
    
    Brigade_Location = data.frame(X = X_Coord, Y = Y_Coord,
                                  info = paste("<b>Brigade Number:</b>", Brigade_Number_Current, "<br/>",
                                               "<b>Suburb:</b>", Brigade_Suburb, "<br/>",
                                               "<b>Postcode:</b>", Brigade_Postcode))
    
    updateNumericInput(session = session,
                        inputId="Neighbours",
                        label = "Neighbours",
                        value = 0,
                       min = 0, max = 20)
    
      leafletProxy("mapPlot") %>%
        addMarkers(data = Brigade_Location, -56, ~64, popup = ~info, group = "NewMarker") %>%
        clearGroup(group = "NewMarker") %>%
        clearGroup(group = "Neighbours") %>%
        clearGroup(group = "BrigadeLocation") %>%
        clearGroup(group = "Incidents") %>%
        addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation")
      if(input$Incidents_SDS){
        SDS_Brigade = as.numeric((Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>%
                                    dplyr::select(`SDS Turnout Time (Secs)`))[1,1])
        
        
        
        Incidents_SDS = FIRS %>% filter(brigade_no == as.numeric(Brigade_Number_Current))
        
        SDS_Difference = difftime(as.POSIXct(Incidents_SDS$primary_arrival_datetime,format="%Y-%m-%d %H:%M:%S"), 
                                  as.POSIXct(Incidents_SDS$primary_turnout_datetime, format="%Y-%m-%d %H:%M:%S"), units = "secs") - SDS_Brigade
        
        SDS_Pass = ifelse(SDS_Difference <= 0, "Y", "N")
        
        leafletProxy("mapPlot") %>%
          addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info, group = "BrigadeLocation") %>%
          addCircles(lng = as.numeric(Incidents_SDS$shape_latitude), lat = as.numeric(Incidents_SDS$shape_longitude),
                     fillOpacity = 1, opacity = 1, color = pal_factor_SDS_Pass(SDS_Pass),
                     popup = paste("<b>Incident Number:</b>", Incidents_SDS$incident_no, "<br/>",
                                   "<b>Date:</b>", ifelse(Incidents_SDS$primary_turnout_datetime, "Unknown",
                                                          as.Date(Incidents_SDS$primary_turnout_datetime)), "<br/>",
                                   "<b>Time:</b>", format(as.POSIXct(Incidents_SDS$primary_arrival_datetime,format="%Y-%m-%d %H:%M:%S"),
                                                          format = "%H:%M:%S"), "<br/>",
                                   "<b>SDS Difference:</b>", SDS_Difference, "<br/>",
                                   "<b>Incident Type:</b>", Incidents_SDS$incident_type_division, "<br/>",
                                   "<b>Suspicious Status:</b>", Incidents_SDS$incident_suspicious_status), group = "Incidents")
          
      }
      
  })
  
  
  # Satellite Map ----
  
  output$SatellitemapPlot <- renderLeaflet({
    X_Coord = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(X))[1,1]
    Y_Coord = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Y))[1,1]
    Brigade_Number_Current = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(`Brigade Number`))[1,1]
    Brigade_Suburb = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Suburb))[1,1]
    Brigade_Postcode = (Vic_Brig_DF %>% filter(
      `BRIGADE NAME` == input$Brigade) %>%
        dplyr::select(Postcode))[1,1]
    Brigade_Location = data.frame(x = X_Coord, y = Y_Coord, info = paste("<b>Brigade Number:</b>", Brigade_Number_Current, "<br/>",
                                                                         "<b>Suburb:</b>", Brigade_Suburb, "<br/>",
                                                                         "<b>Postcode:</b>", Brigade_Postcode))
    
    
    Text_Number_1 = data.frame(x = 147.5, y = -34.25, text = "Brigade Number:")
    Text_Suburb_1 = data.frame(x = 147.5, y = -34.75, text = "Suburb:")
    Text_Postcode_1 = data.frame(x = 147.5, y = -35.25, text = "Postcode:")
    
    Text_Number_2 = data.frame(x = 147.7, y = -34.25, text = Brigade_Number_Current)
    Text_Suburb_2 = data.frame(x = 147.7, y = -34.75, text = Brigade_Suburb)
    Text_Postcode_2 = data.frame(x = 147.7, y = -35.25, text = Brigade_Postcode)
    
    text_size = 6
    
    
    
    
    
    if(input$MapType == "Region"){
      if(input$Focus){
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>% addProviderTiles('Esri.WorldImagery')%>%
            addPolygons(data = Region_sf_Transformed %>% filter(REGION == input$Region),
                        fillOpacity = 0.02, color = "white", weight = 3, opacity = 1) %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(REGION == input$Region),
                        popup = ~paste0("<b>Members</b>: ", Join_Count)) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else{
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = Region_sf_Transformed %>% filter(REGION == input$Region), 
                        fillOpacity = 0.02, color = "white", weight = 3, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }else{
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = Region_sf_Transformed,
                        fillOpacity = 0.02, color = "white", weight = 2, opacity = 1) %>% 
            addPolygons(data = Operational_Members_sf_Transformed,
                        popup = ~paste0("<b>Members</b>: ", Join_Count)) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else{
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = Region_sf_Transformed, 
                        fillOpacity = 0.02, color = "white", weight = 2, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }
      
    }else if(input$MapType == "District"){
      if(input$Focus){
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = District_sf_Transformed %>% filter(DISTRIC == input$District),
                        fillOpacity = 0.02, color = "white", weight = 3, opacity = 1) %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% filter(DISTRIC == input$District),
                        popup = ~paste0("<b>Members</b>: ", Join_Count)) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else{
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = District_sf_Transformed %>% filter(DISTRIC == input$District), 
                        fillOpacity = 0.02, color = "white", weight = 3, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }else{
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = District_sf_Transformed,
                        fillOpacity = 0.02, color = "white", weight = 2, opacity = 1) %>% 
            addPolygons(data = Operational_Members_sf_Transformed, 
                        popup = ~paste0("<b>Members</b>: ", Join_Count)) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else{
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = District_sf_Transformed, 
                        fillOpacity = 0.02, color = "white", weight = 2, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }
      
    }else if(input$MapType == "Brigade"){
      if(input$Focus){
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)),
                        fillOpacity = 0.02, color = "white", weight = 3, opacity = 1) %>% 
            addPolygons(data = Operational_Members_sf_Transformed %>% 
                          filter(Brigade_No == as.numeric(Brigade_Number_Current)), popup = ~paste0("<b>Members</b>: ", Join_Count)) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else{
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolylines(data = Brigade_sf_Transformed %>% filter(BRIG_NO == as.numeric(Brigade_Number_Current)), 
                         fillOpacity = 0.02, color = "white", weight = 3, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }else{
        if(input$MapFeatures == "Member Locations"){
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = Brigade_sf_Transformed,
                        fillOpacity = 0.02, color = "white", weight = 2, opacity = 1) %>% 
            addPolygons(data = Operational_Members_sf_Transformed, popup = ~paste0("<b>Members</b>: ", Join_Count)) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }else{
          leaflet() %>% addProviderTiles('Esri.WorldImagery') %>%
            addPolygons(data = Brigade_sf_Transformed, 
                        fillOpacity = 0.02, color = "white", weight = 2, opacity = 1) %>%
            addMarkers(data = Brigade_Location, ~X, ~Y, popup = ~info)
        }
      }
      
    }
    
    
    
    
    
  })
  
  output$TimeSeries = renderPlot({
    
    if(input$MapType == "Region"){
      Time_Series_df = Vic_Brig_DF %>% filter(REGION == input$Region)
      
      if(input$MapFeatures == "Brigade Environment"){
        Brig_Env_TS = Time_Series_df %>%
          group_by(Year, `Brigade Environment`) %>%
          summarise(frequency = n(), .groups = "drop")
        ggplot(Brig_Env_TS) +
          geom_line(aes(x = Year, y = frequency, group = `Brigade Environment`, colour = `Brigade Environment`), linewidth = 2) +
          theme_bw() + 
          labs(x = "Year", y  = "Number", title = "Brigade Environment Time Series")
      }else if(input$MapFeatures == "Population"){
        Pop_TS = Time_Series_df %>%
          group_by(Year, DISTRICT) %>%
          summarise(Population = sum(Population), .groups = "drop")
        ggplot(Pop_TS) +
          geom_line(aes(x = Year, y = Population, group = DISTRICT, colour = DISTRICT), linewidth = 2) +
          theme_bw() + 
          labs(x = "Year", y  = "Number", title = "Brigade Environment Time Series")
      }
      
    }
    

  })
  
  
  
  # Brigade Characteristics ----
  
  output$BrigadeCharacteristics = renderTable(rownames = FALSE, colnames = FALSE, {
    if(input$Brigade != ""){
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == Current_Year) %>%
                                  dplyr::select(Brigade))[1,1]
      Brigade_Current = Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == Current_Year) %>%
        dplyr::select("Population", "Function Type", "Governance Level", "Land Use", "Brigade Environment", Brigade_Area, BUA, BUA_P)
      
      Number_of_Members = as.integer(sum((Operational_Members_sf_Transformed %>% filter(Brigade_No == as.numeric(Brigade_Number_Current)))$Join_Count))
      
      Population = sum(Brigade_Current$Population)
      
      Member_Percentage = round(Number_of_Members / (Population) * 100, 2)
      
      
      c_names = c(colnames(Brigade_Current)[1:5], "Brigade Area", "Built up Area", "Built Up Percentage", "Members", "Member Percentage")
      
      
      
      Brigade_Table = data.frame(B1 = c_names, B2 = c(t(Brigade_Current[1,]), Number_of_Members, Member_Percentage))
      Brigade_Table
    }else{
      
      Brigade_Current = Vic_Brig_DF %>% 
        dplyr::select("Population", "Function Type", "Governance Level", "Land Use", "Brigade Environment", Brigade_Area, BUA, BUA_P)
      
      c_names = c(colnames(Brigade_Current)[1:5], "Brigade Area", "Built up Area", "Built Up Percentage", "Members", "Member Percentage")
      
      
      
      Brigade_Table = data.frame(B1 = c_names, B2 = "")
      Brigade_Table
    }
    
  })
  
  
  # District Characteristics ----
  
  output$DistrictCharacteristics = renderTable(rownames = FALSE, colnames = FALSE, {
    if(input$District != ""){
      District_Assessment = Vic_Brig_DF %>% filter(DISTRICT == input$District & Year == Current_Year)
      
      Number_of_Brigades =  as.integer(length(unique(District_Assessment$Name)))
      Population = sum(District_Assessment$Population)
      Number_of_Members = as.integer(sum((Operational_Members_sf_Transformed %>% filter(DISTRICT == input$District))$Join_Count))
      
      Member_Percent = round(Number_of_Members/Population * 100, 2)
      
      District_Area = round(sum(District_Assessment$Brigade_Area), 3)
      
      District_BUA = round(sum(District_Assessment$BUA), 2)
      
      
      Land_Use = unique(District_Assessment %>% dplyr::select(Brigade, `Land Use`))
      Land_Use_Table = table(Land_Use$`Land Use`)
      Land_Use_DF = data.frame(Land_Use_Table)
      
      Bushfire = Land_Use_DF %>% filter(Var1 == "Bushfire") %>% dplyr::select(Freq)
      
      if(nrow(Bushfire) == 0){
        Bushfire_Brigades = paste0(as.integer(0), "(0%)")
      }else{
        Bushfire_Brigades = paste0(as.integer(Bushfire[1,1]), " (", round(Bushfire[1,1]/Number_of_Brigades * 100, 2), "%)")
      }
      
      Grassfire = Land_Use_DF %>% filter(Var1 == "Grassfire") %>% dplyr::select(Freq)
      
      if(nrow(Bushfire) == 0){
        Grassfire_Brigades = paste0(as.integer(0), "(0%)")
      }else{
        Grassfire_Brigades = paste0(as.integer(Grassfire[1,1]), " (", round(Grassfire[1,1]/Number_of_Brigades * 100, 2), "%)") 
      }
      
      Brigade_Environment = District_Assessment %>% dplyr::select(Brigade, `Brigade Environment`)
      
      Brigade_Environment_Table = table(Brigade_Environment$`Brigade Environment`)
      
      Brigade_Environment_DF = data.frame(Brigade_Environment_Table)
      
      Brigade_Environment_DF$Freq = paste0(as.integer(Brigade_Environment_DF$Freq),
                                           " (", round(Brigade_Environment_DF$Freq/sum(Brigade_Environment_DF$Freq) * 100, 2), ")")
      colnames(Brigade_Environment_DF) = c("B1", "B2")
      
      
      
      
      c_names = c("Brigades", "Population", "Members", "Member Percentage",
                  "District Area", "District Built Up Area", " ", " ", "Bushfire Brigades", "Grassfire Brigades", " ", " ")
      
      
      
      District_Table = data.frame(B1 = c_names, 
                                  B2 = c(Number_of_Brigades, Population, Number_of_Members,
                                         Member_Percent, District_Area, District_BUA, " ", " ", Bushfire_Brigades, Grassfire_Brigades, " ", " "))
      
      District_Table = rbind(District_Table, Brigade_Environment_DF)
      District_Table
    }else{
      c_names = c("Brigades", "Population", "Members", "Member Percentage",
                  "District Area", "District Built Up Area", " ", " ", "Bushfire Brigades", "Grassfire Brigades", " ", " ",
                  "Agricultural & Natural Environment", "Hybrid", "Structural 1", "Structural 2")
      
      
      
      District_Table = data.frame(B1 = c_names, 
                                  B2 = "")
      District_Table
    }
    
  })
  
  
  
  
  
  # Region Characteristics ----
  
  output$RegionCharacteristics = renderTable(rownames = FALSE, colnames = FALSE, {
    if(input$Region != ""){
      Region_Assessment = Vic_Brig_DF %>% filter(REGION == input$Region & Year == Current_Year)
      
      Number_of_Brigades =  as.integer(length(unique(Region_Assessment$Name)))
      Number_of_Districts =  as.integer(length(unique(Region_Assessment$DISTRICT)))
      Population = sum(Region_Assessment$Population)
      Number_of_Members = as.integer(sum((Operational_Members_sf_Transformed %>% filter(REGION == input$Region))$Join_Count))
      
      Member_Percent = round(Number_of_Members/Population * 100, 2)
      
      Region_Area = round(sum(Region_Assessment$Brigade_Area), 3)
      
      Region_BUA = round(sum(Region_Assessment$BUA), 2)
      
      
      Land_Use = unique(Region_Assessment %>% dplyr::select(Brigade, `Land Use`))
      Land_Use_Table = table(Land_Use$`Land Use`)
      Land_Use_DF = data.frame(Land_Use_Table)
      
      Bushfire = Land_Use_DF %>% filter(Var1 == "Bushfire") %>% dplyr::select(Freq)
      
      if(nrow(Bushfire) == 0){
        Bushfire_Brigades = paste0(as.integer(0), "(0%)")
      }else{
        Bushfire_Brigades = paste0(as.integer(Bushfire[1,1]), " (", round(Bushfire[1,1]/Number_of_Brigades * 100, 2), "%)")
      }
      
      Grassfire = Land_Use_DF %>% filter(Var1 == "Grassfire") %>% dplyr::select(Freq)
      
      if(nrow(Bushfire) == 0){
        Grassfire_Brigades = paste0(as.integer(0), "(0%)")
      }else{
        Grassfire_Brigades = paste0(as.integer(Grassfire[1,1]), " (", round(Grassfire[1,1]/Number_of_Brigades * 100, 2), "%)") 
      }
      
      Brigade_Environment = Region_Assessment %>% dplyr::select(Brigade, `Brigade Environment`)
      
      Brigade_Environment_Table = table(Brigade_Environment$`Brigade Environment`)
      
      Brigade_Environment_DF = data.frame(Brigade_Environment_Table)
      
      Brigade_Environment_DF$Freq = paste0(as.integer(Brigade_Environment_DF$Freq),
                                           " (", round(Brigade_Environment_DF$Freq/sum(Brigade_Environment_DF$Freq) * 100, 2), "%)")
      colnames(Brigade_Environment_DF) = c("B1", "B2")
      
      
      
      
      c_names = c("Districts", "Brigades", "Population", "Members", "Member Percentage",
                  "District Area", "District Built Up Area", " ", " ","Bushfire Brigades", "Grassfire Brigades", " ", " ")
      
      
      
      Region_Table = data.frame(B1 = c_names, 
                                B2 = c(Number_of_Districts, Number_of_Brigades, Population, Number_of_Members,
                                       Member_Percent, Region_Area, Region_BUA, " ", " ", Bushfire_Brigades, Grassfire_Brigades, " ", " "))
      
      Region_Table = rbind(Region_Table, Brigade_Environment_DF)
      Region_Table
    }else{
      c_names = c("Districts", "Brigades", "Population", "Members", "Member Percentage",
                  "District Area", "District Built Up Area", " ", " ","Bushfire Brigades", "Grassfire Brigades", " ", " ",
                  "Agricultural & Natural Environment", "Hybrid", "Structural 1", "Structural 2")
      
      
      
      Region_Table = data.frame(B1 = c_names, 
                                B2 = "")
      
      Region_Table
    }
    
  })
  
  
  
  # Brigade Assessment ----
  
  output$BrigadeAssessment = renderTable(rownames = FALSE, colnames = FALSE,{
    if(input$Brigade != ""){
      Brigade_Assessment = Vic_Brig_DF %>% filter(
        `BRIGADE NAME` == input$Brigade & Year == Current_Year) %>%
        dplyr::select(`SDS Turnout Time (Secs)`, `Observed Turnout (Secs)`, `Previous Quarter`, `Change (Secs)`, `Change (Percentage)`)
      
      c_names = colnames(Brigade_Assessment)
      Brigade_Assesment_Table = data.frame(B1 = c_names, B2 = t(Brigade_Assessment[1,]))
      Brigade_Assesment_Table
    }else{
      c_names = c("SDS Turnout Time (Secs)", "Observed Turnout (Secs)", "Previous Quarter", "Change (Secs)", "Change (Percentage)")
      Brigade_Assesment_Table = data.frame(B1 = c_names, B2 = "")
      Brigade_Assesment_Table
    }
  })
  
  # District Assessment ----
  
  output$DistrictAssessment = renderTable(rownames = FALSE, colnames = FALSE,{
    if(input$District != ""){
      District_Assessment = Vic_Brig_DF %>% filter(DISTRICT == input$District & Year == Current_Year) %>%
        dplyr::select(`SDS Turnout Time (Secs)`, `Observed Turnout (Secs)`, `Previous Quarter`,
               `Change (Secs)`, `Change (Percentage)`, `BRIGADE NAME`)
      
      Percentage_Meeting_SDS = round(mean(District_Assessment$`SDS Turnout Time (Secs)` >= District_Assessment$`Observed Turnout (Secs)`, 
                                          na.rm = TRUE) * 100, 2)
      SDS_Failed_Brigades = District_Assessment %>%
        filter(District_Assessment$`SDS Turnout Time (Secs)` < District_Assessment$`Observed Turnout (Secs)`) %>%
        dplyr::select(`BRIGADE NAME`)
      
      SDS_Failed_Brigades_Combined = paste(sort(SDS_Failed_Brigades$`BRIGADE NAME`), collapse = ", ")
      
      
      c_names = c("SDS Success Percentage", "SDS Failed Brigades")
      
      values = c(Percentage_Meeting_SDS, SDS_Failed_Brigades_Combined)
      
      District_Assessment_Table = data.frame(B1 = c_names, B2 = values)
      
      District_Assessment_Table
    }else{
      c_names = c("SDS Success Percentage", "SDS Failed Brigades")
      
      values = ""
      
      District_Assessment_Table = data.frame(B1 = c_names, B2 = values)
      
      District_Assessment_Table
    }
  })
  
  # Region Assessment ----
  
  output$RegionAssessment = renderTable(rownames = FALSE, colnames = FALSE,{
    if(input$Region != ""){
      Region_Assessment = Vic_Brig_DF %>%
        filter(REGION == input$Region & Year == Current_Year) %>%
        dplyr::select(`SDS Turnout Time (Secs)`, `Observed Turnout (Secs)`,
               `Previous Quarter`, `Change (Secs)`, `Change (Percentage)`, `BRIGADE NAME`, DISTRICT)
      
      Percentage_Meeting_SDS = round(mean(Region_Assessment$`SDS Turnout Time (Secs)` >= Region_Assessment$`Observed Turnout (Secs)`,
                                          na.rm = TRUE) * 100, 2)
      
      
      District_SDS_Percentage = NULL
      for(i in unique(Region_Assessment$DISTRICT)){
        District_Percent = Region_Assessment %>% filter(DISTRICT == i) %>%
          dplyr::select(`SDS Turnout Time (Secs)`, `Observed Turnout (Secs)`, DISTRICT)
        
        District_SDS_Percentage = rbind(District_SDS_Percentage, 
                                        c(i, 
                                          round(mean(District_Percent$`SDS Turnout Time (Secs)` >=
                                                       District_Percent$`Observed Turnout (Secs)`, na.rm = TRUE) * 100, 2)))
        
      }
      
      District_SDS_Percentage = District_SDS_Percentage[order(as.numeric(District_SDS_Percentage[,2]), decreasing = TRUE),]
      
      District_SDS_Percentage_Together = paste0("District ", District_SDS_Percentage[,1], " (", District_SDS_Percentage[,2], "%)")
      
      District_SDS_Percentage_Combined = paste(District_SDS_Percentage_Together, collapse = ", ")
      
      c_names = c("SDS Success Percentage", "District SDS Percentage")
      values = c(Percentage_Meeting_SDS, District_SDS_Percentage_Combined)
      District_Table = data.frame(B1 = c_names, B2 = values)
      District_Table
    }else{
      c_names = c("SDS Success Percentage", "District SDS Percentage")
      values = ""
      District_Table = data.frame(B1 = c_names, B2 = values)
      District_Table
    }
    
    
  })
  
  
  # CFA Overview ----
  
  output$CFAOverview = renderTable(rownames = FALSE, colnames = FALSE,{
    
    Num_Regions = length(Regions)
    Num_Districts = length(Districts)
    Num_Brigades = length(Brigade)
    Num_Members = as.integer(sum(Operational_Members_sf_Transformed$Join_Count))
    
    c_names_1 = c("Number of Regions", "Number of District", "Number of Brigades", "Number of Members")
    values_1 = c(Num_Regions, Num_Districts, Num_Brigades, Num_Members)
    
    c_names_2 = c("Fleet Requirement Satisfication Percentage",
                  "Building Requirement Satisfication Percentage", 
                  "Asset Requirement Satistifaction Percentage", " ")
    values_2 = c(round(mean(Satisfaction_DF_Ordered$Fleet == "Satisfied", na.rm = TRUE) * 100, 2),
                 round(mean(Satisfaction_DF_Ordered$Building == "Satisfied", na.rm = TRUE) * 100, 2),
                 round(mean(Satisfaction_DF_Ordered$Building == "Satisfied" & Satisfaction_DF_Ordered$Fleet == "Satisfied", na.rm = TRUE) * 100, 2),
                 " ")
    
    CFAOverview_Table = data.frame(B1 = c_names_1, B2 = values_1, B3 = " ", B4 = " ", B5 = c_names_2, B6 = values_2, B7 = " ")
    
    CFAOverview_Table
    
  })
  
  
  
  
  # Current Assets Table ----
  
  
  
  output$Current = renderTable({
    if(input$Brigade != ""){
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Brigade Number`))[1,1]
      District_Number_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(DISTRICT))[1,1]
      
      Building_Current = Assets_Buildings %>% filter(Brigade_Number == as.numeric(Brigade_Number_Current))
      
      Building = Building_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`)
      if(nrow(Building) != 0){
        Building_DF = NULL
        for(i in unique(Building$`ASSET SUB CLASS`)){
          Building_Subclass = Building %>% filter(`ASSET SUB CLASS` == i)
          Building_Group = ifelse(!is.na(Building_Subclass$`ASSET TYPOLOGY`),
                                  paste0(Building_Subclass$`ASSET GROUP`," (", Building_Subclass$`ASSET TYPOLOGY`, ")"),
                                  Building_Subclass$`ASSET GROUP`)
          Building_Group_Combined = paste(Building_Group, collapse = ", ")
          Temp_DF = data.frame("Asset_Class" = "Building", "Asset_Subclass" = i, "Asset" = Building_Group_Combined)
          Building_DF = rbind(Building_DF, Temp_DF)
        }
      }else{
        Building_DF = data.frame("Asset_Class" = "Building", "Asset_Subclass" = "Unknown", "Asset" = "Unknown")
      }
      
      
      Fleet_Current = Assets_Fleet %>% filter(Brigade_Number == as.numeric(Brigade_Number_Current))
      Fleet = Fleet_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`)
      if(nrow(Fleet) != 0){
        Fleet_DF = NULL
        for(i in unique(Fleet$`ASSET SUB CLASS`)){
          Fleet_Subclass = Fleet %>% filter(`ASSET SUB CLASS` == i)
          Fleet_Group = ifelse(!is.na(Fleet_Subclass$`ASSET TYPOLOGY`),
                               paste0(Fleet_Subclass$`ASSET GROUP`," (", Fleet_Subclass$`ASSET TYPOLOGY`, ")"),
                               Fleet_Subclass$`ASSET GROUP`)
          Fleet_Group_Combined = paste(Fleet_Group, collapse = ", ")
          Temp_DF = data.frame("Asset_Class" = "Fleet", "Asset_Subclass" = i, "Asset" = Fleet_Group_Combined)
          Fleet_DF = rbind(Fleet_DF, Temp_DF)
        }
      }else{
        Fleet_DF = data.frame("Asset_Class" = "Fleet", "Asset_Subclass" = "Unknown", "Asset" = "Unknown")
      }
      
      
      PPE_Current = Assets_PPE %>% filter(Brigade_Number == as.numeric(Brigade_Number_Current))
      PPE = PPE_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, Brigade_Number)
      
      PPE$District_Check = ifelse(is.na(PPE$Brigade_Number),
                                  paste0(PPE$`ASSET GROUP`, " (D)"),
                                  PPE$`ASSET GROUP`)
      if(nrow(PPE) != 0){
        PPE_DF = NULL
        for(i in unique(PPE$`ASSET SUB CLASS`)){
          PPE_Subclass = PPE %>% filter(`ASSET SUB CLASS` == i)
          
          PPE_Table = table(PPE_Subclass$District_Check)
          PPE_Table_DF = as.data.frame(PPE_Table)
          
          
          
          PPE_District_Check_Combined = ifelse(PPE_Table_DF$Freq == 1, 
                                               as.character(PPE_Table_DF$Var1), 
                                               paste0(as.character(PPE_Table_DF$Var1), " x ", PPE_Table_DF$Freq))
          
          
          PPE_Group_Combined = paste(PPE_District_Check_Combined, collapse = ", ")
          Temp_DF = data.frame("Asset_Class" = "PPE", "Asset_Subclass" = i, "Asset" = PPE_Group_Combined)
          PPE_DF = rbind(PPE_DF, Temp_DF)
        }
      }else{
        PPE_DF = data.frame("Asset_Class" = "PPE", "Asset_Subclass" = "Unknown", "Asset" = "Unknown")
      }
      
      
      Current_Table = rbind(Building_DF, Fleet_DF, PPE_DF)
      colnames(Current_Table) = c("Class", "Sub Class", "Asset")
      Current_Table
      
    }else{
      Class = rep("", 3)
      Sub_Class = ""
      Asset = ""
      s1 = ""
      s2 = ""
      s3 = ""
      s4 = ""
      Current_Table = data.frame("Class" = Class, s1, s2, "Sub Class" = Sub_Class, s3, s4, "Asset" = Asset)
      colnames(Current_Table) = c("Class", " ", " ", "Sub Class", " ", " ", "Asset")
      Current_Table
    }
    
    
    
  })
  
  # Current District Asset Table ----
  
  output$DistrictAssets = renderTable({
    if(input$District != ""){
      District_Number_Current = (Vic_Brig_DF %>% filter(DISTRICT == input$District) %>% dplyr::select(DISTRICT))[1,1]
      
      Building_Current = Assets_Buildings %>% filter(
        (District == as.character(District_Number_Current) & is.na(Brigade_Number)))
      Building = Building_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`)
      Building_DF = NULL
      for(i in unique(Building$`ASSET SUB CLASS`)){
        Building_Subclass = Building %>% filter(`ASSET SUB CLASS` == i)
        Building_Group = ifelse(!is.na(Building_Subclass$`ASSET TYPOLOGY`),
                                paste0(Building_Subclass$`ASSET GROUP`," (", Building_Subclass$`ASSET TYPOLOGY`, ")"),
                                Building_Subclass$`ASSET GROUP`)
        Building_Group_Combined = paste(Building_Group, collapse = ", ")
        Temp_DF = data.frame("Asset_Class" = "Building", "Asset_Subclass" = i, "Asset" = Building_Group_Combined)
        Building_DF = rbind(Building_DF, Temp_DF)
      }
      
      
      Fleet_Current = Assets_Fleet %>% filter(District ==as.character(District_Number_Current) & is.na(Brigade_Number))
      
      PPE_Current = Assets_PPE %>% filter(District == as.character(District_Number_Current) & is.na(Brigade_Number))
      
      if(nrow(Fleet_Current) != 0 | nrow(PPE_Current) != 0){
        Fleet = Fleet_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`)
        
        Fleet = Fleet %>% filter(!is.na(`ASSET CLASS`) & is.na(`ASSET SUB CLASS`) & !is.na(`ASSET GROUP`))
        
        Fleet$District_Check = Fleet$`ASSET GROUP`
        
        Fleet_DF = NULL
        for(i in unique(Fleet$`ASSET SUB CLASS`)){
          Fleet_Subclass = Fleet %>% filter(`ASSET SUB CLASS` == i & !is.na(`ASSET GROUP`))
          
          Fleet_Group = ifelse(!is.na(Fleet_Subclass$`ASSET TYPOLOGY`),
                               paste0(Fleet_Subclass$`ASSET GROUP`," (", Fleet_Subclass$`ASSET TYPOLOGY`, ")"),
                               Fleet_Subclass$`ASSET GROUP`)
          
          Fleet_Table = table(Fleet_Group)
          
          Fleet_Table_DF = as.data.frame(Fleet_Table)
          
          Fleet_District_Check_Combined = ifelse(Fleet_Table_DF$Freq == 1, 
                                                 as.character(Fleet_Table_DF$Var1), 
                                                 paste0(as.character(Fleet_Table_DF$Var1), " x ", Fleet_Table_DF$Freq))
          
          
          
          Fleet_District_Combined = paste(Fleet_District_Check_Combined, collapse = ", ")
          Temp_DF = data.frame("Asset_Class" = "Fleet", "Asset_Subclass" = i, "Asset" = Fleet_District_Check_Combined)
          Fleet_DF = rbind(Fleet_DF, Temp_DF)
          
          
        }
        
        
        PPE_Current = Assets_PPE %>% filter(District == as.character(District_Number_Current) & is.na(Brigade_Number))
        PPE = PPE_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, Brigade_Number)
        
        PPE$District_Check = PPE$`ASSET GROUP`
        
        PPE_DF = NULL
        for(i in unique(PPE$`ASSET SUB CLASS`)){
          PPE_Subclass = PPE %>% filter(`ASSET SUB CLASS` == i)
          
          PPE_Table = table(PPE_Subclass$District_Check)
          PPE_Table_DF = as.data.frame(PPE_Table)
          
          
          
          PPE_District_Check_Combined = ifelse(PPE_Table_DF$Freq == 1, 
                                               as.character(PPE_Table_DF$Var1), 
                                               paste0(as.character(PPE_Table_DF$Var1), " x ", PPE_Table_DF$Freq))
          
          
          PPE_Group_Combined = paste(PPE_District_Check_Combined, collapse = ", ")
          Temp_DF = data.frame("Asset_Class" = "PPE", "Asset_Subclass" = i, "Asset" = PPE_Group_Combined)
          PPE_DF = rbind(PPE_DF, Temp_DF)
        }
        
        Current_Table = rbind(Building_DF, Fleet_DF, PPE_DF)
        colnames(Current_Table) = c("Class", "Sub Class", "Asset")
        
        Current_Table
      }else{
        Class = rep("", 3)
        Sub_Class = ""
        Asset = ""
        s1 = ""
        s2 = ""
        s3 = ""
        s4 = ""
        Current_Table = data.frame("Class" = Class, s1, s2, "Sub Class" = Sub_Class, s3, s4, "Asset" = Asset)
        colnames(Current_Table) = c("Class", " ", " ", "Sub Class", " ", " ", "Asset")
        Current_Table
      }
      
      
      
      
    }else{
      Class = rep("", 3)
      Sub_Class = ""
      Asset = ""
      s1 = ""
      s2 = ""
      s3 = ""
      s4 = ""
      Current_Table = data.frame("Class" = Class, s1, s2, "Sub Class" = Sub_Class, s3, s4, "Asset" = Asset)
      colnames(Current_Table) = c("Class", " ", " ", "Sub Class", " ", " ", "Asset")
      Current_Table
    }
    
    
    
  })
  
  
  # Expected Assets Table ----
  
  output$Expected = renderTable({
    if(input$Brigade != ""){
      Brigade_Expected = Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == Current_Year)
      Incidents_Expected = (Incidents_Most_Recent %>% filter(Name == input$Brigade) %>% 
                              dplyr::select(`Yearly Avg Structure Incidents 2017 to 2021`))[1,1]
      
      Population_Class = Population_Classifier(Brigade_Expected$Population, Brigade_Expected$`Land Use`)
      BUA_Class = Built_Up_Classifier(Brigade_Expected$BUA, Brigade_Expected$`Land Use`)
      Structure_Incidents_Class = Structure_Fires_Classifier(Incidents_Expected, Brigade_Expected$`Land Use`)
      Community_Risk_Expected = Community_Risk_Classifier(Population_Class, BUA_Class, Structure_Incidents_Class)
      Brigade_Environment_Expected = Brigade_Environment_Classifier_2(Community_Risk_Expected,
                                                                      Population_Class, BUA_Class, Structure_Incidents_Class)
      
      Station_Expected = Station_Requirement(Brigade_Environment_Expected)
      
      Fleet_Expected = Fleet_Requirement(Brigade_Environment_Expected)
      
      
      
      
      Brigade_Number_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Brigade Number`))[1,1]
      Building_Current = Assets_Buildings %>% filter(Brigade_Number == as.numeric(Brigade_Number_Current))
      
      Building = Building_Current %>% filter(`ASSET SUB CLASS` == "Fire Station") %>% dplyr::select(`ASSET TYPOLOGY`)
      
      Fleet_Current = Assets_Fleet %>% filter(Brigade_Number == as.numeric(Brigade_Number_Current))
      Fleet = Fleet_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`)
      
      
      Station_Met = Station_Expectation_Satisfied(Brigade_Environment_Expected, Building)
      
      Fleet_Met = Fleet_Expectation_Satisfied(Brigade_Environment_Expected, Fleet %>% dplyr::select(`ASSET GROUP`),
                                              Fleet %>% dplyr::select(`ASSET TYPOLOGY`))

      
      
      
      
      
      Expected_df = data.frame(Class = c("Station", "Fleet"),
                               Asset = c(Station_Expected, Fleet_Expected),
                               Status = c(Station_Met, Fleet_Met))
      
      Expected_df
    }else{
      Class = rep("", 3)
      Sub_Class = ""
      Asset = ""
      s1 = ""
      s2 = ""
      s3 = ""
      s4 = ""
      Current_Table = data.frame("Class" = Class, s1, s2, "Sub Class" = Sub_Class, s3, s4, "Asset" = Asset)
      colnames(Current_Table) = c("Class", " ", " ", "Sub Class", " ", " ", "Status")
      Current_Table
    }
    
    
    
    
    
    
    
  })
  
  
  # Forecast Assets Table ----
  
  
  output$Forecast = renderTable({
    if(input$Brigade != ""){
      Brigade_Forecast = Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year)
      
      Population_Class = Population_Classifier(input$Population, input$LandUse)
      BUA_Class = Built_Up_Classifier(input$Density * Brigade_Forecast$Brigade_Area/100, input$LandUse)
      Structure_Incidents_Class = Structure_Fires_Classifier(input$Incidents, input$LandUse)
      
      Community_Risk_Forecast = Community_Risk_Classifier(Population_Class, BUA_Class, Structure_Incidents_Class)
      Brigade_Environment_Forecast = Brigade_Environment_Classifier_2(Community_Risk_Forecast,
                                                                      Population_Class, BUA_Class, Structure_Incidents_Class)
      
      
      Station_Forecast = Station_Requirement(Brigade_Environment_Forecast)
      
      Fleet_Forecast = Fleet_Requirement(Brigade_Environment_Forecast)
      
      District_Number_Forecast = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(DISTRICT))[1,1]
      Brigade_Number_Forecast = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Brigade Number`))[1,1]
      Building_Forecast = Assets_Buildings %>% filter(Brigade_Number == as.numeric(Brigade_Number_Forecast))
      
      Building = Building_Forecast %>% filter(`ASSET SUB CLASS` == "Fire Station") %>% dplyr::select(`ASSET TYPOLOGY`)
      
      Fleet_Current = Assets_Fleet %>% filter(Brigade_Number == as.numeric(Brigade_Number_Forecast))
      Fleet = Fleet_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`)
      
      
      Station_Met = Station_Expectation_Satisfied(Brigade_Environment_Forecast, Building)
      
      Fleet_Met = Fleet_Expectation_Satisfied(Brigade_Environment_Forecast, Fleet %>% dplyr::select(`ASSET GROUP`),
                                              Fleet %>% dplyr::select(`ASSET TYPOLOGY`))
      
      
      Forecast_df = data.frame(Class = c("Station", "Fleet"),
                               Asset = c(Station_Forecast, Fleet_Forecast),
                               Status = c(Station_Met, Fleet_Met))
      
      Forecast_df
    }else{
      Class = rep("", 3)
      Sub_Class = ""
      Asset = ""
      s1 = ""
      s2 = ""
      s3 = ""
      s4 = ""
      Current_Table = data.frame("Class" = Class, s1, s2, "Sub Class" = Sub_Class, s3, s4, "Asset" = Asset)
      colnames(Current_Table) = c("Class", " ", " ", "Sub Class", " ", " ", "Status")
      Current_Table
    }
    
    
    
    
  })
  
  
  # Scenario Assets Table ----
  
  output$Scenario = renderTable(colnames = FALSE, {
    
    Brigade_Number_Scenario = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Brigade Number`))[1,1]
    Fleet_Current = Assets_Fleet %>% filter(Brigade_Number == as.numeric(Brigade_Number_Scenario))
    
    if(input$Brigade != ""){
      if(nrow(Fleet_Current) != 0){
        Brigade_Scenario = Vic_Brig_DF %>% filter( 
          `BRIGADE NAME` == input$Brigade & Year == Current_Year)
        
        
        District_Number_Scenario = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(DISTRICT))[1,1]
        
        Population_Class = Population_Classifier(input$Population, input$LandUse)
        BUA_Class = Built_Up_Classifier(input$Density * Brigade_Scenario$Brigade_Area/100, input$LandUse)
        Structure_Incidents_Class = Structure_Fires_Classifier(input$Incidents, input$LandUse)
        Community_Risk = Community_Risk_Classifier(Population_Class, BUA_Class, Structure_Incidents_Class)
        Brigade_Environment = Brigade_Environment_Classifier_2(Community_Risk,
                                                               Population_Class, BUA_Class, 
                                                               Structure_Incidents_Class)
        
        Out = Hazard_Classifier(input$Population)
        
        
        Fleet = Fleet_Current %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`, `CALC REM LIFE (YRS)`)
        
        
        
        
        FSEC = Fleet_Scenario_Expectation_Cost(Brigade_Environment, Fleet %>% dplyr::select(`ASSET GROUP`),
                                               Fleet %>% dplyr::select(`ASSET TYPOLOGY`))
        
        if(FSEC[1,1] != 0){
          
          FSEC_min = NULL
          FSEC_max = NULL
          
          for(i in unique(FSEC$out_2)){
            FSEC_sub = FSEC %>% filter(out_2 == i)
            FSEC_sub = FSEC[order(FSEC$`REPLACEMENT COST ($)`),]
            FSEC_Group = ifelse(!is.na(FSEC_sub$`ASSET TYPOLOGY`),
                                paste0(FSEC_sub$`ASSET GROUP`, " (", FSEC_sub$`ASSET TYPOLOGY`, ")"),
                                FSEC_sub$`ASSET GROUP`)
            
            FSEC_min_fleet = FSEC_Group[1]
            FSEC_min_cost = FSEC$`REPLACEMENT COST ($)`[1]
            FSEC_min = rbind(FSEC_min, data.frame(Asset = FSEC_min_fleet, Cost = FSEC_min_cost))
            
            FSEC_max_fleet = FSEC_Group[length(FSEC_Group)]
            FSEC_max_cost = FSEC$`REPLACEMENT COST ($)`[nrow(FSEC)]
            FSEC_max = rbind(FSEC_max, data.frame(Asset = FSEC_max_fleet, Cost = FSEC_max_cost))
          }
        }else{
          FSEC_min = data.frame(Asset = " ", Cost = 0)
        }
        
        
        Fleet_Upgrade_Assets = paste0(FSEC_min$Asset, collapse = ", ")
        Fleet_Upgrade_Cost = sum(FSEC_min$Cost)
        
        
        Fleet$Retired = ifelse(as.numeric(input$Year) - as.numeric(Current_Year) > as.numeric(Fleet$`CALC REM LIFE (YRS)`), 1, 0)
        
        Fleet_Retired = Fleet %>% filter(Retired == 1)
        
        
        Fleet_Group_Combined = NULL
        Fleet_Replacement_Cost = 0
        
        if(sum(Fleet$Retired) == 0){
          
          Fleet_Group_Combined = NULL
          Fleet_Replacement_Cost = 0
          
        }else{
          
          Fleet_R = Fleet %>% filter(Retired == 1)
          Fleet_R_updated = NULL
          
          if(FSEC[1,1] != 0){
            
            for(i in 1:nrow(Fleet_R)){
              
              Fleet_Upgrade = FSEC %>% filter(`ASSET GROUP` == Fleet_R$`ASSET GROUP`[i])
              
              if(nrow(Fleet_Upgrade) == 0){
                Fleet_R_updated = rbind(Fleet_R_updated, Fleet_R[i,])
              }
              
            }
            
          }else{
            Fleet_R_updated = Fleet_R
          }
          
          if(!is.null(Fleet_R_updated)){
            Fleet_Group = ifelse(!is.na(Fleet_R_updated$`ASSET TYPOLOGY`),
                                 paste0(Fleet_R_updated$`ASSET GROUP`," (", Fleet_R_updated$`ASSET TYPOLOGY`, ")"),
                                 Fleet_R_updated$`ASSET GROUP`)
            
            Fleet_Group_Combined = paste(Fleet_Group, collapse = ", ")
            
            Fleet_Replacement_Cost_df = Asset_Plan_Fleet %>% filter(`ASSET CLASS` == Fleet_R_updated$`ASSET CLASS` &
                                                                      `ASSET SUB CLASS` == Fleet_R_updated$`ASSET SUB CLASS` &
                                                                      `ASSET GROUP` == Fleet_R_updated$`ASSET GROUP` &
                                                                      `ASSET TYPOLOGY` == Fleet_R_updated$`ASSET TYPOLOGY`) %>%
              dplyr::select(`REPLACEMENT COST ($)`)
            Fleet_Replacement_Cost = sum(Fleet_Replacement_Cost_df)
          }
          
          
          
        }
        
        ### Buildings Retired
        
        Building_Scenario = Assets_Buildings %>% filter(Brigade_Number == as.numeric(Brigade_Number_Scenario)|
                                                          (District == as.character(District_Number_Scenario) & is.na(Brigade_Number)))
        Building = Building_Scenario %>% dplyr::select(`ASSET CLASS`, `ASSET SUB CLASS`, `ASSET GROUP`, `ASSET TYPOLOGY`, `CALC REM LIFE (YRS)`)
        
        Building$Retired = ifelse(as.numeric(input$Year) - as.numeric(Current_Year) > as.numeric(Building$`CALC REM LIFE (YRS)`), 1, 0)
        
        Building_Retired = Building %>% filter(Retired == 1)
        
        
        BSEC = Building_Scenario_Expectation_Cost(Brigade_Environment, Building %>% dplyr::select(`ASSET TYPOLOGY`))
        
        if(BSEC[2] != ""){
          Building_Group_Combined = ""
          Building_Replacement_Cost = 0
        }else{
          if(sum(Building$Retired) == 0){
            Building_Group_Combined = ""
            Building_Replacement_Cost = 0
          }else{
            Building_R = Building %>% filter(Retired == 1)
            Building_Group = ifelse(!is.na(Building_R$`ASSET TYPOLOGY`),
                                    paste0(Building_R$`ASSET SUB CLASS`," (", Building_R$`ASSET TYPOLOGY`, ")"),
                                    Building_R$`ASSET GROUP`)
            Building_Group_Combined = paste(Building_Group, collapse = ", ")
            
            Building_Replacement_Cost_df = Asset_Building_Plan %>% filter(`ASSET CLASS` == Building_Retired$`ASSET CLASS` &
                                                                            `ASSET SUB CLASS` == Building_Retired$`ASSET SUB CLASS` &
                                                                            `ASSET GROUP` == Building_Retired$`ASSET GROUP` &
                                                                            `ASSET TYPOLOGY` == Building_Retired$`ASSET TYPOLOGY`) %>%
              dplyr::select(`REPLACEMENT COST ($'000)`)
            Building_Replacement_Cost = sum(Building_Replacement_Cost_df)
          }
          
        }
        if(Building_Group_Combined == "" & !is.null(Fleet_Group_Combined)){
          Asset_Retired = Fleet_Group_Combined
        }else{
          Asset_Retired = paste0(c(Building_Group_Combined, Fleet_Group_Combined), collapse = ", ")
        }
        
        
        if(identical(Asset_Retired, character(0))){
          Asset_Retired = ""
        }
        
        Asset_Replacement_Cost = Building_Replacement_Cost * 1000 + Fleet_Replacement_Cost
        
        
        
        
        
        
        #Gap = 0
        #if(FSEC[2] != ""){
        #  for(i in 1:nrow(FSEC)){
        #    Gap = Gap + 1
        #    Fleet_Retired = Fleet_Retired %>% filter()
        #  }
        #}
        
        
        
        Classes = c("Community Risk Environment", "Brigade Environment", Out$Type, "Assets Retired",
                    "Asset Replacement Cost", "Fleet Upgrade", "Fleet Upgrade Cost", "Building Upgrade", "Building Upgrade Cost")
        Values = c(Community_Risk, Brigade_Environment, Out$Class, Asset_Retired, paste0("$", Asset_Replacement_Cost),
                   Fleet_Upgrade_Assets, paste0("$", Fleet_Upgrade_Cost), BSEC[2], paste0("$", as.numeric(BSEC[1]) * 1000))
        Scenario_Table = data.frame(B1 = Classes, B2 = Values)
        colnames(Scenario_Table) = c("Outlook", " ")
        Scenario_Table
      }else{
        Brigade_Scenario = Vic_Brig_DF %>% filter( 
          `BRIGADE NAME` == input$Brigade & Year == Current_Year)
        
        
        District_Number_Scenario = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(DISTRICT))[1,1]
        
        Population_Class = Population_Classifier(input$Population, input$LandUse)
        BUA_Class = Built_Up_Classifier(input$Density * Brigade_Scenario$Brigade_Area/100, input$LandUse)
        Structure_Incidents_Class = Structure_Fires_Classifier(input$Incidents, input$LandUse)
        Community_Risk = Community_Risk_Classifier(Population_Class, BUA_Class, Structure_Incidents_Class)
        Brigade_Environment = Brigade_Environment_Classifier_2(Community_Risk,
                                                               Population_Class, BUA_Class, 
                                                               Structure_Incidents_Class)
        
        Out = Hazard_Classifier(input$Population)
        
        Classes = c("Community Risk Environment", "Brigade Environment", Out$Type, "Assets Retired",
                    "Asset Replacement Cost", "Fleet Upgrade", "Fleet Upgrade Cost", "Building Upgrade", "Building Upgrade Cost")
        Values = c(Community_Risk, Brigade_Environment, Out$Class, "", "",
                   "", "", "", "")
        Scenario_Table = data.frame(B1 = Classes, B2 = Values)
        colnames(Scenario_Table) = c("Outlook", " ")
        Scenario_Table
      }
    }else{
      Classes = c("Community Risk Environment", "Brigade Environment", "Hazard Class", "Vehicle Response Time",
                  "Brigade Classification", "Station Typology", "Primary Response Appliance", "BOSP", "Assets Retired",
                  "Asset Replacement Cost", "Fleet Upgrade", "Fleet Upgrade Cost", "Building Upgrade", "Building Upgrade Cost")
      Values = c("")
      Scenario_Table = data.frame(B1 = Classes, B2 = Values)
      colnames(Scenario_Table) = c("Outlook", " ")
      Scenario_Table
    }
    
    
    
    
    
    
    
    
    
  })
  
  # Reset Location Inputs Button ----
  
  observeEvent(input$reset_Location_input, {
    
 
    Neighbours = NULL
    
    updateSelectizeInput(session = session,
      inputId ="Region",
                      label = "Region",
                      choices = sort(Regions),
                      selected = "",
                      server = TRUE
    )
    
    
    
    
    updateSelectizeInput(session = session,
      inputId = "District",
                      label = "District",
                      choices = sort(Districts),
                      selected = "",
                      server = TRUE)
    
    updateSelectizeInput(session = session,
                      inputId = "Brigade",
                      label = "Brigade",
                      choices = sort(Brigade),
                      selected = "",
                      server = TRUE)
    
    updateSliderInput(session = session, 
                      inputId ="Incidents",
                      label = "Incidents",
                      value = 0,
                      min = 0,
                      max = 60
    )
    
    updateCheckboxInput(inputId = "Incidents_SDS",
                        label = "Incidents",
                        value = FALSE)
    
    updateCheckboxInput(inputId = "FRV",
                        label = "FRV Response",
                        value = FALSE)
    
    updateCheckboxInput(inputId = "FRVDistrict",
                        label = "FRV District",
                        value = FALSE)
    
    
    
    
    Current_Year = as.numeric(format(Sys.Date(), "%Y"))
    
    updateSliderInput(session = session,
                      inputId = "Population",
                      label = "Population",
                      value = 0,
                      min = 0,
                      max = 100000)
    
    
    
    
    
    updateNumericInput(session = session,
                       inputId = "Density",
                       label = "Density",
                       value = 0,
                       min = 0,
                       max = 100, step = 0.01)
    
    leafletProxy("mapPlot") %>%
      clearGroup(group = "NewMarker") %>%
      clearGroup(group = "Neighbours")
    
    
    updateNumericInput(session = session,
                        inputId="Neighbours",
                        label = "Neighbours",
                        value = 0, min = 0, max = 20)
    
    
    
  })
  
  
  # Reset Scenario Inputs Button ----
  
  observeEvent(input$reset_input, {
    
    Incidents = (Incidents_Most_Recent %>% filter(Name == input$Brigade) %>% dplyr::select(`Yearly Avg Structure Incidents 2017 to 2021`))[1,1]
    
    Pop = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>%
         dplyr::select(Population))[1,1]
    Density = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade & Year == input$Year) %>%
         dplyr::select(BUA_P))[1,1]
    
    
    
    
    if(input$Brigade != ""){
      updateSliderInput(session = session, 
                        inputId ="Incidents",
                        label = "Incidents",
                        value = floor(as.numeric(Incidents)),
                        min = 0,
                        max = 60
      )
      
      
      
      
      Current_Year = as.numeric(format(Sys.Date(), "%Y"))
      
      updateSliderInput(session = session,
                        inputId = "Population",
                        label = "Population",
                        value = as.numeric(Pop),
                        min = 0,
                        max = 100000)
      
      
      
      
      
      updateNumericInput(session = session,
                         inputId = "Density",
                         label = "Density",
                         value = round(as.numeric(Density), 3),
                         min = 0,
                         max = 100, step = 0.01)
      
      L_Use_Current = (Vic_Brig_DF %>% filter(`BRIGADE NAME` == input$Brigade) %>% dplyr::select(`Land Use`))[1,1]
      
      updateSelectizeInput(session = session, 
                        inputId ="LandUse",
                        label = "Land Use",
                        choices = c("Grassfire", "Bushfire"),
                        selected = L_Use_Current)
    }else if(input$Brigade != ""){
      updateSliderInput(session = session, 
                        inputId ="Incidents",
                        label = "Incidents",
                        value = 0,
                        min = 0,
                        max = 60
      )
      
      
      
      
      Current_Year = as.numeric(format(Sys.Date(), "%Y"))
      
      updateSliderInput(session = session,
                        inputId = "Population",
                        label = "Population",
                        value = 0,
                        min = 0,
                        max = 100000)
      
      
      
      
      
      updateNumericInput(session = session,
                         inputId = "Density",
                         label = "Density",
                         value = 0,
                         min = 0,
                         max = 100, step = 0.01)
      
      
      updateSelectizeInput(session = session, 
                        inputId ="LandUse",
                        label = "Land Use",
                        choices = c("Grassfire", "Bushfire"),
                        selected = "")
    }
    
    
    
    
  })
  
}