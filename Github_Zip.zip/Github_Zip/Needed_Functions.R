Population_Classifier = function(Population, Land_Use){
  if(Population < 350){
    if(Land_Use == "Grassfire"){
      Community_Risk_Class = "Grassfire-Agricultural"
    }else{
      Community_Risk_Class = "Bushfire"
    }
  }else if(Population >= 350 & Population < 1000){
    if(Land_Use == "Grassfire"){
      Community_Risk_Class = 'Grassfire-Agricultural with Structure'
    }else{
      Community_Risk_Class = 'Bushfire with Structure'
    }
  }else if(Population >= 1000 & Population < 5000){
    if(Land_Use == "Grassfire"){
      Community_Risk_Class = 'Structure with Grassfire-Agricultural'
    }else{
      Community_Risk_Class = 'Structure with Bushfire'
    }
  }else if(Population >= 5000){
    Community_Risk_Class = 'Structure'
  }else{
    Community_Risk_Class = 'Problem'
  }
  return(Community_Risk_Class)
  
}


Structure_Fires_Classifier = function(Incidents, Land_Use){
  if(Incidents < 1){
    if(Land_Use == "Grassfire"){
      Structure_Fires = "Grassfire-Agricultural"
    }else{
      Structure_Fires = "Bushfire"
    }
  }else if(Incidents >= 1 & Incidents <3){
    if(Land_Use == "Grassfire"){
      Structure_Fires = "Grassfire-Agricultural with Structure"
    }else{
      Structure_Fires = "Bushfire with Structure"
    }
  }else if(Incidents >= 3 & Incidents < 6){
    if(Land_Use == "Grassfire"){
      Structure_Fires = "Structure with Grassfire-Agricultural"
    }else{
      Structure_Fires = "Structure with Bushfire"
    }
  }else if(Incidents >= 6){
    Structure_Fires = "Structure"
  }else{
    Structure_Fires = "Problem"
  }
  return(Structure_Fires)
}


Built_Up_Classifier = function(BUA, Land_Use){
  if(BUA < 10){
    if(Land_Use == "Grassfire"){
      Built_Up_Area = "Grassfire-Agricultural"
    }else{
      Built_Up_Area = "Bushfire"
    }
  }else if(BUA >= 10 & BUA < 100){
    if(Land_Use == "Grassfire"){
      Built_Up_Area = "Grassfire-Agricultural with Structure"
    }else{
      Built_Up_Area = "Bushfire with Structure"
    }
  }else if(BUA >= 100 & BUA < 300){
    if(Land_Use == "Grassfire"){
      Built_Up_Area = "Structure with Grassfire-Agricultural"
    }else{
      Built_Up_Area = "Structure with Bushfire"
    }
  }else if(BUA >= 300){
    Built_Up_Area = "Structure"
  }
  return(Built_Up_Area)
}

Community_Risk_Classifier = function(PC, SFC, BUC){
  Classifier = c(PC, SFC, BUC)
  Class_DF = data.frame(table(Classifier))
  Class_DF = Class_DF[order(Class_DF$Freq, decreasing = TRUE),]
  if(max(Class_DF$Freq) == 1){
    out = "Undefined"
  }else{
    out = Class_DF[1,1]
  }
  return(as.character(out))
}

Community_Risk_Classifier('Structure with Bushfire', "Grassfire-Agricultural with Structure", "Structure")


Brigade_Environment_Classifier_2 = function(Community_Risk, PC, SFC, BUC){
  if(Community_Risk == "Grassfire-Agricultural" | Community_Risk == "Bushfire"){
    B_Class = "Agricultural and Natural Environment"
  }else if(Community_Risk == "Grassfire-Agricultural with Structure" | Community_Risk == "Bushfire with Structure"){
    B_Class = "Hybrid"
  }else if(Community_Risk == "Structure with Grassfire-Agricultural" | Community_Risk == "Structure with Bushfire"){
    B_Class = "Structure 1"
  }else if(Community_Risk == "Structure"){
    B_Class = "Structure 2"
  }else{
    sub_classes = c(PC, SFC, BUC)
    Holder = NULL
    for(i in sub_classes){
      if(i == "Grassfire-Agricultural" | i == "Bushfire"){
        Holder = c(Holder, "Agricultural and Natural Environment")
      }else if(i == "Grassfire-Agricultural with Structure" | i == "Bushfire with Structure"){
        Holder = c(Holder, "Hybrid")
      }else if(i == "Structure with Grassfire-Agricultural" | i == "Structure with Bushfire"){
        Holder = c(Holder, "Structure 1")
      }else if(i == "Structure"){
        Holder = c(Holder, "Structure 2")
      }
    }
    Holder_DF = data.frame(table(Holder))
    Holder_DF = Holder_DF[order(Holder_DF$Freq, decreasing = TRUE),]
    if(max(Holder_DF$Freq) == 1){
      
      # Need to replace this
      
      X_sorted = sort(Holder)
      if(X_sorted[3] == "Structure 2"){
        B_Class = "Structure 1"
      }else{
        B_Class = "Hybrid"
      }
      
      
    }else{
      B_Class = as.character(Holder_DF[1,1])
    }
    
  }
  return(B_Class)
}

Hazard_Classifier = function(Population){
  if(Population >= 15000){
    Brigade_Classification = "Class 5"
    Hazard_Class = "High Urban"
    Station_Typology = "Integrated Stations * 2B"
    Primary_Response_Appliance = "Pumper (H), Tanker (H), Specialist Appliance"
    BOSP = "Structural, Bushfire"
    Vehicle_Response_Time = "N/A"
  }else if(Population < 15000 & Population >= 4500){
    Brigade_Classification = "Class 4"
    Hazard_Class = "Medium Urban"
    Station_Typology = "2A - 2B"
    Primary_Response_Appliance = "Pumper (H), Tanker (H), Specialist Appliance"
    BOSP = "Structural, Bushfire"
    Vehicle_Response_Time = "8"
  }else if(Population < 4500 & Population >= 1400){
    Brigade_Classification = "Class 3"
    Hazard_Class = "Low Urban"
    Station_Typology = "1C"
    Primary_Response_Appliance = "Tanker (M/H), Pumper Tanker, Pumper (L/M)"
    BOSP = "Bushfire, Structual"
    Vehicle_Response_Time = "10"
  }else if(Population < 1400 & Population >= 500){
    Brigade_Classification = "Class 2"
    Hazard_Class = "Rural"
    Station_Typology = "1B - 1B1"
    Primary_Response_Appliance = "Tanker (ULT/L/M/H)"
    BOSP = "Bushfire Low, Structural"
    Vehicle_Response_Time = "20"
  }else if(Population < 500){
    Brigade_Classification = "Class 1"
    Hazard_Class = "Remote Rural"
    Station_Typology = "1A1 - 1A3"
    Primary_Response_Appliance = "Tanker (L/M/H)"
    BOSP = "Bushfire"
    Vehicle_Response_Time = "Not Specified"
  }
  
  out = data.frame(Type = c("Hazard Class", "Vehicle Response Time", "Brigade Classification", "Station Typology", "Primary Response Appliance",
                            "BOSP"),
                   Class = c(Hazard_Class, Vehicle_Response_Time, Brigade_Classification, Station_Typology, Primary_Response_Appliance,
                             BOSP))
  return(out)
}


Station_Requirement = function(Brigade_Environment){
  if(Brigade_Environment == "Agricultural and Natural Environment"){
    out = "1A"
  }else if(Brigade_Environment == "Hybrid"){
    out = "1B"
  }else if(Brigade_Environment == "Structure 1"){
    out = "1C"
  }else if(Brigade_Environment == "Structure 2"){
    out = "2B"
  }
  return(out)
}


Fleet_Requirement = function(Brigade_Environment){
  if(Brigade_Environment == "Agricultural and Natural Environment"){
    out = "Tanker with a capacity between 500 to 9000L​"
  }else if(Brigade_Environment == "Hybrid"){
    out = "Medium or Heavy Tanker with pumping capacity >900 Lpm​"
  }else if(Brigade_Environment == "Structure 1"){
    out = "(Light Pumper or Pumper Tanker (2000Lpm)) and Tanker (Medium (2.4C))​"
  }else if(Brigade_Environment == "Structure 2"){
    out = "Medium Pumper (3000Lpm) and Tanker (Medium (2.4C))"
  }
  return(out)
}


Station_Expectation_Satisfied = function(Brigade_Environment, Station_Current){
  if(nrow(Station_Current) != 0){
    if(Brigade_Environment == "Agricultural and Natural Environment"){
      if(grepl("1A|1B|1C|2A|2B", Station_Current)){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else if(Brigade_Environment == "Hybrid"){
      if(grepl("1B|1C|2A|2B", Station_Current)){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else if(Brigade_Environment == "Structure 1"){
      if(grepl("1C|2A|2B", Station_Current)){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else if(Brigade_Environment == "Structure 2"){
      if(grepl("2B", Station_Current)){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else{
      out = "Not Specified"
    }
  }else{
    out = "Unknown"
  }
  return(out)
}


Fleet_Expectation_Satisfied = function(Brigade_Environment, Fleet_Current_Group, Fleet_Current_Typology){
  if(nrow(Fleet_Current_Group) != 0){
    if(Brigade_Environment == "Agricultural and Natural Environment"){
      if(sum(Fleet_Current_Group == "Tanker") > 0){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else if(Brigade_Environment == "Hybrid"){
      if(sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" |
                                                Fleet_Current_Typology == "Heavy" |
                                                Fleet_Current_Typology == "Ultra Heavy")) > 0){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else if(Brigade_Environment == "Structure 1"){
      if((sum(Fleet_Current_Group == "Pumper" | Fleet_Current_Group == "Pumper Tanker") > 0) & 
         sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) > 0){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else if(Brigade_Environment == "Structure 2"){
      if((sum(Fleet_Current_Group == "Pumper" & (Fleet_Current_Typology == "Medium" | Fleet_Current_Typology == "Heavy")) > 0) & 
         sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) > 0){
        out = "Satisfied"
      }else{
        out = "Unsatisfied"
      }
    }else{
      out = "Not Specified"
    }
  }else{
    out = "Unknown"
  }
  return(out)
}



Fleet_Scenario_Expectation_Cost = function(Brigade_Environment, Fleet_Current_Group, Fleet_Current_Typology){
  if(nrow(Fleet_Current_Group) == 0){
    out_1 = 0
    out_2 = 0
  }else{
    out_1 = 0
    out_2 = 0
    if(Brigade_Environment == "Agricultural and Natural Environment"){
      if(sum(Fleet_Current_Group == "Tanker") > 0){
        out_1 = 0
      }else{
        
        out_1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Tanker") %>% 
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_2 = 1
      }
      
      
    }else if(Brigade_Environment == "Hybrid"){
      
      if(sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" |
                                                Fleet_Current_Typology == "Heavy" |
                                                Fleet_Current_Typology == "Ultra Heavy")) > 0){
        
        out_1 = 0
        
      }else{
        out_1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Tanker") %>%
          filter(`ASSET TYPOLOGY` == "Medium (2.4C)" | `ASSET TYPOLOGY` == "Heavy")  %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_2 = 2
      }
      
      
      
      
    }else if(Brigade_Environment == "Structure 1"){
      
      if((sum(Fleet_Current_Group == "Pumper" | Fleet_Current_Group == "Pumper Tanker") > 0) & 
         sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) > 0){
        
        out_1 = 0
        
      }else if(sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) > 0 &
               (sum(Fleet_Current_Group == "Pumper" | Fleet_Current_Group == "Pumper Tanker") == 0)){
        
        out_1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Pumper" | `ASSET GROUP` == "Pumper Tanker")  %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          filter(`ASSET TYPOLOGY` == "Light" | `ASSET TYPOLOGY` == "Medium" | `ASSET TYPOLOGY` == "Heavy" | is.na(`ASSET TYPOLOGY`)) %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_2 = rep(1, 4)
        
      }else if(sum(Fleet_Current_Group == "Tanker"& (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) == 0 &
               (sum(Fleet_Current_Group == "Pumper" | Fleet_Current_Group == "Pumper Tanker") > 0)){
        
        out_1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Tanker") %>% filter(`ASSET TYPOLOGY` == "Medium (2.4C)" | `ASSET TYPOLOGY` == "Heavy") %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_2 = 1
        
      }else if(sum(Fleet_Current_Group == "Tanker"& (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) == 0 &
               (sum(Fleet_Current_Group == "Pumper"  | Fleet_Current_Group == "Pumper Tanker") == 0)){
        
        out_1.1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Pumper" | `ASSET GROUP` == "Pumper Tanker") %>%
          filter(`ASSET TYPOLOGY` == "Light" | `ASSET TYPOLOGY` == "Medium" | `ASSET TYPOLOGY` == "Heavy" | is.na(`ASSET TYPOLOGY`))  %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        out_1.2 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Tanker") %>%
          filter(`ASSET TYPOLOGY` == "Medium (2.4C)", "Heavy") %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_1 = rbind(out_1.1, out_1.2)
        
        out_2 = c(1, 1, 1, 1, 2, 2)
      }
      
      
      
    }else if(Brigade_Environment == "Structure 2"){
      if((sum(Fleet_Current_Group == "Pumper" & (Fleet_Current_Typology == "Medium" | Fleet_Current_Typology == "Heavy")) > 0) & 
         sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) > 0){
        
        out_1 = 0
        
      }else if((sum(Fleet_Current_Group == "Pumper" & (Fleet_Current_Typology == "Medium" | Fleet_Current_Typology == "Heavy")) == 0) & 
               sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) > 0){
        
        out_1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Pumper") %>% 
          filter(`ASSET TYPOLOGY` == "Medium" | `ASSET TYPOLOGY` == "Heavy") %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_2 = 1
      }else if((sum(Fleet_Current_Group == "Pumper" & (Fleet_Current_Typology == "Medium" | Fleet_Current_Typology == "Heavy")) > 0) & 
               sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) == 0){
        
        out_1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Tanker") %>% 
          filter(`ASSET TYPOLOGY` == "Medium (2.4C)" | `ASSET TYPOLOGY` == "Heavy") %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_2 = 1
        
      }else if((sum(Fleet_Current_Group == "Pumper" & (Fleet_Current_Typology == "Medium" | Fleet_Current_Typology == "Heavy")) == 0) & 
               sum(Fleet_Current_Group == "Tanker" & (Fleet_Current_Typology == "Medium (2.4C)" | Fleet_Current_Typology == "Heavy")) == 0){
        
        out_1.1 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Pumper") %>%
          filter(`ASSET TYPOLOGY` == "Medium" | `ASSET TYPOLOGY` == "Heavy")  %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        out_1.2 = Asset_Plan_Fleet %>% filter(`ASSET GROUP` == "Tanker") %>%
          filter(`ASSET TYPOLOGY` == "Medium (2.4C)" | `ASSET TYPOLOGY` == "Heavy") %>%
          filter(`ASSET SUB CLASS` == "Emergency Response") %>%
          dplyr::select(`ASSET GROUP`, `ASSET TYPOLOGY`, `REPLACEMENT COST ($)`)
        
        out_1 = rbind(out_1.1, out_1.2)
        
        out_2 = c(1, 1, 2, 2)
      }
    }
  }
  
  out = cbind(out_1, out_2)
  return(out)
}



Building_Scenario_Expectation_Cost = function(Brigade_Environment, Station_Current){
  if(nrow(Station_Current) == 0){
    out_1 = 0
    out_2 = ""
  }else{
    out_2 = ""
    if(Brigade_Environment == "Agricultural and Natural Environment"){
      if(grepl("1A|1B|1C|2A|2B", Station_Current)){
        out_1 = 0
      }else{
        out_1 = min(Asset_Building_Plan %>% filter(`ASSET TYPOLOGY` == "1A") %>% dplyr::select(`REPLACEMENT COST ($'000)`))
        out_2 = "Fire Station (1A)"
      }
    }else if(Brigade_Environment == "Hybrid"){
      if(grepl("1B|1C|2A|2B", Station_Current)){
        out_1 = 0
      }else{
        out_1 = min(Asset_Building_Plan %>% filter(`ASSET TYPOLOGY` == "1B") %>% dplyr::select(`REPLACEMENT COST ($'000)`))
        out_2 = "Fire Station (1B)"
      }
    }else if(Brigade_Environment == "Structure 1"){
      if(grepl("1C|2A|2B", Station_Current)){
        out_1 = 0
      }else{
        out_1 = min(Asset_Building_Plan %>% filter(`ASSET TYPOLOGY` == "1C") %>% dplyr::select(`REPLACEMENT COST ($'000)`))
        out_2 = "Fire Station (1C)"
      }
    }else if(Brigade_Environment == "Structure 2"){
      if(grepl("2B", Station_Current)){
        out_1 = 0
      }else{
        out_1 = min(Asset_Building_Plan %>% filter(`ASSET TYPOLOGY` == "2B") %>% dplyr::select(`REPLACEMENT COST ($'000)`))
        out_2 = "Fire Station (2B)"
      }
    }
  }
  return(c(out_1, out_2))
}

