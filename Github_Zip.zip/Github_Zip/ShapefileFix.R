# Brigade

Brigade_sf_Region = NULL
for(i in Brigade_sf_Transformed$BRIG_NO){
  Brigade_Region = (Vic_Brig_DF %>% filter(`Brigade Number` == i) %>% dplyr::select(REGION))[1,1]
  Brigade_sf_Region = c(Brigade_sf_Region, Brigade_Region)
}

Brigade_sf_Transformed$REGION = Brigade_sf_Region




Brigade_sf_Fleet_Satisfied = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Brigade_sf_Building_Satisfied = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Brigade_sf_Asset_Satisfied = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Brigade_Structure = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Brigade_Members = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Brigade_Population = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Brigade_BUA = rep(NA, length(Brigade_sf_Transformed$BRIG_NO))

Satisfaction_DF_Ordered$Fleet = ifelse(is.na(Satisfaction_DF_Ordered$Fleet), "Unknown", Satisfaction_DF_Ordered$Fleet)
Satisfaction_DF_Ordered$Building = ifelse(is.na(Satisfaction_DF_Ordered$Building), "Unknown", Satisfaction_DF_Ordered$Building)

for(i in 1:length(Brigade_sf_Transformed$BRIG_NO)){
  
  Brig_NO = Brigade_sf_Transformed$BRIG_NO[i]
  
  Brigade_Single = Satisfaction_DF_Ordered %>% filter(Brigade_Number == Brig_NO)
  
  Vic_Brigade = (Vic_Brig_DF %>% filter(`Brigade Number` == Brig_NO) %>% dplyr::select(`Brigade Environment`))[1,1]
  Vic_Population = (Vic_Brig_DF %>% filter(`Brigade Number` == Brig_NO & Year == 2024) %>% dplyr::select(Population))[1,1]
  Vic_BUA = (Vic_Brig_DF %>% filter(`Brigade Number` == Brig_NO & Year == 2024) %>% dplyr::select(BUA))[1,1]
  
  Members = as.integer(sum((Operational_Members_sf_Transformed %>% filter(Brigade_No == Brig_NO))$Join_Count))
  
  Brigade_Members[i] = Members
  
  Brigade_Structure[i] = Vic_Brigade
  
  Brigade_Population[i] = Vic_Population
  
  Brigade_BUA[i] = Vic_BUA
  
  if(nrow(Brigade_Single) > 0){
    if(Brigade_Single$Fleet == "Satisfied"){
      Brigade_sf_Fleet_Satisfied[i] = "Satisfied"
    }else if(Brigade_Single$Fleet == "Unsatisfied"){
      Brigade_sf_Fleet_Satisfied[i] = "Unsatisfied"
    }else{
      Brigade_sf_Fleet_Satisfied[i] = "Unknown"
    }
    
    if(Brigade_Single$Building == "Satisfied"){
      Brigade_sf_Building_Satisfied[i] = "Satisfied"
    }else if(Brigade_Single$Building != "Unsatisfied"){
      Brigade_sf_Building_Satisfied[i] = "Unsatisfied"
    }else{
      Brigade_sf_Building_Satisfied[i] = "Unknown"
    }
    
    if(Brigade_Single$Building == "Satisfied" & Brigade_Single$Fleet == "Satisfied"){
      Brigade_sf_Asset_Satisfied[i] = "Satisfied"
    }else if(Brigade_Single$Building == "Unsatisfied" | Brigade_Single$Fleet == "Unsatisfied"){
      Brigade_sf_Asset_Satisfied[i] = "Unsatisfied"
    }else{
      Brigade_sf_Asset_Satisfied[i] = "Unknown"
    }
    
    
  }
  
  
}

Brigade_sf_Transformed$Fleet = Brigade_sf_Fleet_Satisfied
Brigade_sf_Transformed$Building = Brigade_sf_Building_Satisfied
Brigade_sf_Transformed$Asset = Brigade_sf_Asset_Satisfied
Brigade_sf_Transformed$Environment = Brigade_Structure
Brigade_sf_Transformed$Members = Brigade_Members
Brigade_sf_Transformed$Population = Brigade_Population
Brigade_sf_Transformed$BUA = Brigade_BUA

Required_DF_Ordered = read.csv("Required_DF_Ordered")

Brigade_sf_Transformed$Info_Asset = paste("<b>Region:</b>", Brigade_sf_Transformed$REGION, "<br/>",
                                          "<strong>","District:</b>",Brigade_sf_Transformed$DISTRCT, "<br/>",
                                          "<strong>","Brigade Number:</b>",Brigade_sf_Transformed$BRIG_NO, "<br/>",
                                          "<strong>","Brigade Name:</b>",Brigade_sf_Transformed$BRIG_NA,
                                          ifelse(Required_DF_Ordered$Building != "" & Required_DF_Ordered$Building != 0,
                                                 paste("<br/>", "<b>Building Upgrade:</b>",Required_DF_Ordered$Building), ""),
                                          ifelse(Required_DF_Ordered$Fleet != ""& Required_DF_Ordered$Fleet != 0,
                                                 paste("<br/>", "<strong>","Fleet Upgrade:</b>",Required_DF_Ordered$Fleet), ""))

Brigade_sf_Transformed$Info_Fleet = paste("<strong>","Region:</b>",Brigade_sf_Transformed$REGION, "<br/>",
                                          "<strong>","District:</b>",Brigade_sf_Transformed$DISTRCT, "<br/>",
                                          "<strong>","Brigade Number:</b>",Brigade_sf_Transformed$BRIG_NO, "<br/>",
                                          "<strong>","Brigade Name:</b>",Brigade_sf_Transformed$BRIG_NA,
                                          ifelse(Required_DF_Ordered$Fleet != "" & Required_DF_Ordered$Fleet != 0,
                                                 paste("<br/>", "<strong>","Fleet Upgrade:</b>",Required_DF_Ordered$Fleet), ""))

Brigade_sf_Transformed$Info_Building = paste("<strong>","Region:</b>",Brigade_sf_Transformed$REGION, "<br/>",
                                             "<strong>","District:</b>",Brigade_sf_Transformed$DISTRCT, "<br/>",
                                             "<strong>","Brigade Number:</b>",Brigade_sf_Transformed$BRIG_NO, "<br/>",
                                             "<strong>","Brigade Name:</b>",Brigade_sf_Transformed$BRIG_NA,
                                             ifelse(Required_DF_Ordered$Building != "" & Required_DF_Ordered$Building != 0,
                                                    paste("<br/>", "<b>Building Upgrade:</b>",Required_DF_Ordered$Building), ""))

Brigade_sf_Transformed$Info = paste("<b>Region:</b>",Brigade_sf_Transformed$REGION, "<br/>",
                                    "<b>District:</b>",Brigade_sf_Transformed$DISTRCT, "<br/>",
                                    "<b>Brigade Number:</b>",Brigade_sf_Transformed$BRIG_NO, "<br/>",
                                    "<b>Brigade Name:</b>",Brigade_sf_Transformed$BRIG_NA, "<br/>",
                                    "<b>Environment:</b>",Brigade_sf_Transformed$Environment, "<br/>",
                                    "<b>Population:</b>",Brigade_sf_Transformed$Population, "<br/>",
                                    "<b>Members:</b>",Brigade_sf_Transformed$Members)






# District

District_sf_Fleet_Satisfied = rep(NA, length(District_sf_Transformed$DISTRIC))

District_sf_Building_Satisfied = rep(NA, length(District_sf_Transformed$DISTRIC))

District_sf_Asset_Satisfied = rep(NA, length(District_sf_Transformed$DISTRIC))

District_sf_Agri = rep(NA, length(District_sf_Transformed$DISTRIC))
District_sf_Hybrid = rep(NA, length(District_sf_Transformed$DISTRIC))
District_sf_Structure_1 = rep(NA, length(District_sf_Transformed$DISTRIC))
District_sf_Structure_2 = rep(NA, length(District_sf_Transformed$DISTRIC))

District_sf_Population = rep(NA, length(District_sf_Transformed$DISTRIC))
District_sf_Members = rep(NA, length(District_sf_Transformed$DISTRIC))

District_sf_Region = rep(NA, length(District_sf_Transformed$DISTRIC))
District_sf_NumberBrigades = rep(NA, length(District_sf_Transformed$DISTRIC))

k = 1
for(i in District_sf_Transformed$DISTRIC){
  District_single = Satisfaction_DF_Ordered %>% filter(District == i)
  District_sf_Fleet_Satisfied[k] = mean(District_single$Fleet == "Satisfied")
  District_sf_Building_Satisfied[k] = mean(District_single$Building == "Satisfied")
  District_sf_Asset_Satisfied[k] = mean(District_single$Fleet == "Satisfied" & District_single$Building == "Satisfied")
  District_Vic = Vic_Brig_DF %>% filter(DISTRICT == i & Year == 2024) %>% dplyr::select(`Brigade Environment`, Population, REGION)
  
  District_sf_Agri[k] = mean(District_Vic$`Brigade Environment` == "Agricultural & Natural Environment") * 100
  District_sf_Hybrid[k] = mean(District_Vic$`Brigade Environment` == "Hybrid") * 100
  District_sf_Structure_1[k] = mean(District_Vic$`Brigade Environment` == "Structural 1") * 100
  District_sf_Structure_2[k] = mean(District_Vic$`Brigade Environment` == "Structural 2") * 100
  
  District_sf_Population[k] = sum(District_Vic$Population, na.rm = TRUE)
  District_sf_Members[k] = as.integer(sum((Operational_Members_sf_Transformed %>% filter(DISTRICT == i))$Join_Count))
  
  District_sf_Region[k] = District_Vic$REGION[1]
  
  District_sf_NumberBrigades[k] = nrow(District_Vic)
  
  
  k = k + 1
}


District_sf_Transformed$Fleet = round(District_sf_Fleet_Satisfied * 100, 2)
District_sf_Transformed$Building = round(District_sf_Building_Satisfied * 100, 2)
District_sf_Transformed$Asset = round(District_sf_Asset_Satisfied * 100, 2)

District_sf_Transformed$Agricultural = round(District_sf_Agri, 2)
District_sf_Transformed$Hybrid = round(District_sf_Hybrid, 2)
District_sf_Transformed$Structure_1 = round(District_sf_Structure_1, 2)
District_sf_Transformed$Structure_2 = round(District_sf_Structure_2, 2)

District_sf_Transformed$Population = District_sf_Population
District_sf_Transformed$Members = District_sf_Members

District_sf_Transformed$REGION = District_sf_Region

District_sf_Transformed$Number_of_Brigades = District_sf_NumberBrigades

District_sf_Transformed$Info = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                     "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                     "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                     "<b>Population:</b>",District_sf_Transformed$Population, "<br/>",
                                     "<b>Members:</b>",District_sf_Transformed$Members)

District_sf_Transformed$Info_Agri = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                          "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                          "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                          "<b>Number of Agricultural & Natural Environment Brigades:</b>",
                                          round(District_sf_Transformed$Agricultural * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                          "<b>Agricultural & Natural Environment Brigade Percentage:</b>",District_sf_Transformed$Agricultural)

District_sf_Transformed$Info_Hybrid = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                            "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                            "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                            "<b>Number of Hybrid Brigades:</b>"
                                            ,round(District_sf_Transformed$Hybrid * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                            "<b>Hybrid Brigade Percentage:</b>",District_sf_Transformed$Hybrid)

District_sf_Transformed$Info_Structure_1 = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                                 "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                                 "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                                 "<b>Number of Structual 1:</b>"
                                                 ,round(District_sf_Transformed$Structure_1 * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                                 "<b>Structual 1 Brigade Percentage:</b>",District_sf_Transformed$Structure_1)

District_sf_Transformed$Info_Structure_2 = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                                 "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                                 "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                                 "<b>Number of Structual 2 Brigades:</b>",
                                                 round(District_sf_Transformed$Structure_2 * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                                 "<b>Structual 2 Brigade Percentage:</b>",District_sf_Transformed$Structure_2)


District_sf_Transformed$Info_Asset = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                           "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                           "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                           "<b>Number of Asset Satisfactory Brigades:</b>",
                                           round(District_sf_Transformed$Asset * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                           "<b>Satisfactory Asset Brigade Percentage:</b>",District_sf_Transformed$Asset)

District_sf_Transformed$Info_Fleet = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                           "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                           "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                           "<b>Number of Fleet Satisfactory Brigades:</b>",
                                           round(District_sf_Transformed$Fleet * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                           "<b>Satisfactory Fleet Brigade Percentage:", District_sf_Transformed$Fleet)

District_sf_Transformed$Info_Building = paste("<b>Region:</b>",District_sf_Transformed$REGION, "<br/>",
                                              "<b>District:</b>",District_sf_Transformed$DISTRIC, "<br/>",
                                              "<b>Number of Brigades:</b>",District_sf_Transformed$Number_of_Brigades, "<br/>",
                                              "<b>Number of Building Satisfactory Brigades:</b>",
                                              round(District_sf_Transformed$Building * District_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                              "<b>Satisfactory Building Brigade Percentage:</b>",District_sf_Transformed$Asset)


# Region

Region_sf_Fleet_Satisfied = rep(NA, length(Region_sf_Transformed$REGION))

Region_sf_Building_Satisfied = rep(NA, length(Region_sf_Transformed$REGION))

Region_sf_Asset_Satisfied = rep(NA, length(Region_sf_Transformed$REGION))

Region_sf_Agri = rep(NA, length(Region_sf_Transformed$REGION))
Region_sf_Hybrid = rep(NA, length(Region_sf_Transformed$REGION))
Region_sf_Structure_1 = rep(NA, length(Region_sf_Transformed$REGION))
Region_sf_Structure_2 = rep(NA, length(Region_sf_Transformed$REGION))

Region_sf_Population = rep(NA, length(Region_sf_Transformed$REGION))
Region_sf_Members = rep(NA, length(Region_sf_Transformed$REGION))

Region_sf_Number_of_Regions = rep(NA, length(Region_sf_Transformed$REGION))
Region_sf_NumberBrigades = rep(NA, length(Region_sf_Transformed$REGION))

k = 1
for(i in Region_sf_Transformed$REGION){
  Region_single = Satisfaction_DF_Ordered %>% filter(Region == i)
  Region_sf_Fleet_Satisfied[k] = mean(Region_single$Fleet == "Satisfied")
  Region_sf_Building_Satisfied[k] = mean(Region_single$Building == "Satisfied")
  Region_sf_Asset_Satisfied[k] = mean(Region_single$Fleet == "Satisfied" & Region_single$Building == "Satisfied")
  Region_Vic = Vic_Brig_DF %>% filter(REGION == i & Year == 2024) %>% dplyr::select(`Brigade Environment`, Population, DISTRICT)
  
  Region_sf_Agri[k] = mean(Region_Vic$`Brigade Environment` == "Agricultural & Natural Environment") * 100
  Region_sf_Hybrid[k] = mean(Region_Vic$`Brigade Environment` == "Hybrid") * 100
  Region_sf_Structure_1[k] = mean(Region_Vic$`Brigade Environment` == "Structural 1") * 100
  Region_sf_Structure_2[k] = mean(Region_Vic$`Brigade Environment` == "Structural 2") * 100
  
  Region_sf_Population[k] = sum(Region_Vic$Population, na.rm = TRUE)
  Region_sf_Members[k] = as.integer(sum((Operational_Members_sf_Transformed %>% filter(REGION == i))$Join_Count))
  
  Region_sf_Number_of_Regions[k] = length(unique(Region_Vic$DISTRICT))
  
  Region_sf_NumberBrigades[k] = nrow(Region_Vic)
  
  
  k = k + 1
}


Region_sf_Transformed$Fleet = round(Region_sf_Fleet_Satisfied * 100, 2)
Region_sf_Transformed$Building = round(Region_sf_Building_Satisfied * 100, 2)
Region_sf_Transformed$Asset = round(Region_sf_Asset_Satisfied * 100, 2)

Region_sf_Transformed$Agricultural = round(Region_sf_Agri, 2)
Region_sf_Transformed$Hybrid = round(Region_sf_Hybrid, 2)
Region_sf_Transformed$Structure_1 = round(Region_sf_Structure_1, 2)
Region_sf_Transformed$Structure_2 = round(Region_sf_Structure_2, 2)

Region_sf_Transformed$Population = Region_sf_Population
Region_sf_Transformed$Members = Region_sf_Members

Region_sf_Transformed$Number_of_Districts = Region_sf_Number_of_Regions

Region_sf_Transformed$Number_of_Brigades = Region_sf_NumberBrigades

Region_sf_Transformed$Info = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                   "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                   "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                   "<b>Population:</b>",Region_sf_Transformed$Population, "<br/>",
                                   "<b>Members:</b>",Region_sf_Transformed$Members)

Region_sf_Transformed$Info_Agri = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                        "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                        "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                        "<b>Number of Agricultural & Natural Environment Brigades:</b>",
                                        round(Region_sf_Transformed$Agricultural * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                        "<b>Agricultural & Natural Environment Brigade Percentage:</b>",Region_sf_Transformed$Agricultural)

Region_sf_Transformed$Info_Hybrid = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                          "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                          "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                          "<b>Number of Hybrid Brigades:</b>",
                                          round(Region_sf_Transformed$Hybrid * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                          "<b>Hybrid Brigade Percentage:</b>",Region_sf_Transformed$Hybrid)

Region_sf_Transformed$Info_Structure_1 = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                               "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                               "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                               "<b>Number of Structual 1:</b>",
                                               round(Region_sf_Transformed$Structure_1 * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                               "<b>Structual 1 Brigade Percentage:</b>",Region_sf_Transformed$Structure_1)

Region_sf_Transformed$Info_Structure_2 = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                               "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                               "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                               "<b>Number of Structual 2 Brigades:</b>",
                                               round(Region_sf_Transformed$Structure_2 * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                               "<b>Structual 2 Brigade Percentage:</b>",Region_sf_Transformed$Structure_2)


Region_sf_Transformed$Info_Asset = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                         "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                         "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                         "<b>Number of Asset Satisfactory Brigades:</b>",
                                         round(Region_sf_Transformed$Asset * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                         "<b>Satisfactory Asset Brigade Percentage:</b>",Region_sf_Transformed$Asset)

Region_sf_Transformed$Info_Fleet = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                         "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                         "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                         "<b>Number of Fleet Satisfactory Brigades:</b>",
                                         round(Region_sf_Transformed$Fleet * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                         "<b>Satisfactory Fleet Brigade Percentage:</b>",Region_sf_Transformed$Fleet)

Region_sf_Transformed$Info_Building = paste("<b>Region:</b>",Region_sf_Transformed$REGION, "<br/>",
                                            "<b>Number of District:</b>",Region_sf_Transformed$Number_of_Districts, "<br/>",
                                            "<b>Number of Brigades:</b>",Region_sf_Transformed$Number_of_Brigades, "<br/>",
                                            "<b>Number of Building Satisfactory Brigades:</b>",
                                            round(Region_sf_Transformed$Building * Region_sf_Transformed$Number_of_Brigades / 100), "<br/>",
                                            "<b>Satisfactory Building Brigade Percentage:</b>",Region_sf_Transformed$Asset)
