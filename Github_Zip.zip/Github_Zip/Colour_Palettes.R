pal_binary_Environment = colorFactor("Greys",
                                     domain = factor(Brigade_sf_Transformed$Envrnmn), na.color = "white")

pal_binary_asset = colorFactor(c("#4CAB86", "#ffdb00", "#E4002b"),
                                     domain = factor(Brigade_sf_Transformed$Asset), na.color = "white")
pal_binary_fleet = colorFactor(c("#4CAB86", "#ffdb00", "#E4002b"),
                               domain = factor(Brigade_sf_Transformed$Fleet), na.color = "white")
pal_binary_building = colorFactor(c("#4CAB86", "#E4002b", "#ffdb00"),
                               domain = factor(Brigade_sf_Transformed$Buildng), na.color = "white")

pal_bin_Population = colorBin("Blues",
                              domain = range(as.numeric(Brigade_sf_Transformed$Popultn), na.rm = TRUE), na.color = "#808080",
                              bins = 5)

pal_bin_BUA = colorBin("Purples",
                       domain = range(as.numeric(Brigade_sf_Transformed$BUA), na.rm = TRUE), na.color = "#808080",
                       bins = 5)

pal_bin_Environment_District = colorBin("Greens",
                                        domain = range(c(District_sf_Transformed$Agrcltr,
                                                         District_sf_Transformed$Hybrid,
                                                         District_sf_Transformed$Strct_1,
                                                         District_sf_Transformed$Strct_2), na.rm = TRUE), na.color = "#808080",
                                        bins = 5)

pal_bin_Assets_District = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                   domain = range(c(District_sf_Transformed$Fleet,
                                                    District_sf_Transformed$Buildng,
                                                    District_sf_Transformed$Asset), na.rm = TRUE), na.color = "#808080",
                                   bins = 5, reverse = TRUE)

pal_bin_District_Population = colorBin("Blues",
                                       domain = range(as.numeric(District_sf_Transformed$Popultn), na.rm = TRUE), na.color = "#808080",
                                       bins = 5)

pal_bin_District_Member_Numbers = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                           domain = range(as.numeric(District_sf_Transformed$Members), na.rm = TRUE), na.color = "#808080",
                                           bins = 5, reverse = TRUE)

pal_bin_Brigade_Member_Numbers = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                          domain = range(as.numeric(Brigade_sf_Transformed$Members), na.rm = TRUE), na.color = "#808080",
                                          bins = 5, reverse = TRUE)

pal_bin_Assets_Region = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                 domain = range(c(Region_sf_Transformed$Fleet,
                                                  Region_sf_Transformed$Buildng,
                                                  Region_sf_Transformed$Asset), na.rm = TRUE), na.color = "#808080",
                                 bins = 5, reverse = TRUE)

pal_bin_Environment_Region = colorBin("Greens",
                                      domain = range(c(District_sf_Transformed$Agrcltr,
                                                       District_sf_Transformed$Hybrid,
                                                       District_sf_Transformed$Strct_1,
                                                       District_sf_Transformed$Strct_2), na.rm = TRUE), na.color = "#808080",
                                      bins = 5)

pal_bin_Region_Population = colorBin("Blues",
                                     domain = range(as.numeric(Region_sf_Transformed$Popultn), na.rm = TRUE), na.color = "#808080",
                                     bins = 5)

pal_bin_Region_Member_Numbers = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                         domain = range(as.numeric(Region_sf_Transformed$Members), na.rm = TRUE), na.color = "#808080",
                                         bins = 5, reverse = TRUE)


pal_bin_Region_Members = colorBin("Blues",
                                     domain = range(as.numeric(Operational_Members_sf_Transformed$Join_Count), na.rm = TRUE), na.color = "#808080",
                                     bins = 6)

pal_factor_SDS_Pass = colorFactor(c("#4CAB86", "#E4002b"),
                                  domain = factor(c("Y", "N"), levels = c("Y", "N")))



pal_bin_Brigade_Member_Locations = colorBin(c("#4CAB86", "#ffdb00", "#E4002b"),
                                          domain = range(as.numeric(Operational_Members_sf_Transformed$Join_Count), na.rm = TRUE), na.color = "#808080",
                                          bins = 5, reverse = TRUE)



