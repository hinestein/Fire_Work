FIRS_Brigades = unique(FIRS$brigade_no)


Brigade_Speed_DF = NULL
for(i in FIRS_Brigades){
  Temp = FIRS %>% filter(brigade_no == i)
  Brigade_Single = Vic_Brig_DF %>% filter(Brigade == i)
  
  Brigade_Speed = NULL
  
  for(j in 1:nrow(Temp)){
    dist_1 = distCosine(rbind(c(Brigade_Single$X[1], Brigade_Single$Y[1]),
                              c(as.numeric(Temp$shape_latitude)[j], as.numeric(Temp$shape_longitude)[j])))
    
    Time_Taken = difftime(as.POSIXct(Temp$primary_arrival_datetime[j],format="%Y-%m-%d %H:%M:%S"), 
                 as.POSIXct(Temp$primary_turnout_datetime[j], format="%Y-%m-%d %H:%M:%S"), units = "secs")
    

    speed = dist_1/as.numeric(Time_Taken)
    Temp_DF = data.frame(Brigade = i, Speed = speed)
    Brigade_Speed = rbind(Brigade_Speed, Temp_DF)
  }
  Brigade_Speed_DF = rbind(Brigade_Speed_DF, data.frame(Brigade = i, Average_Speed = median(Brigade_Speed$Speed, na.rm = TRUE),
                                                        Observations = nrow(Temp), ENvironment = Brigade_Single$`Brigade Environment`[1],
                                                        SDS = Brigade_Single$`SDS Turnout Time (Secs)`[1]))
}




ggplot(Brigade_Speed_DF %>% filter(!is.na(ENvironment))) + geom_boxplot(aes(x = ENvironment, y = Average_Speed)) + theme_bw() +
  labs(x = "Brigade Environment", y = "Average Speed (m/s)")

ggplot(Brigade_Speed_DF %>% filter(!is.na(ENvironment))) + geom_boxplot(aes(x = ENvironment, y = Observations)) + theme_bw() +
  labs(x = "Brigade Environment", y = "Number of Observations")


Brigade_Speed_DF = Brigade_Speed_DF %>% filter(Average_Speed < 50 & !is.na(ENvironment))



Average_Speed = NULL
for(i in 1:nrow(Vic_Brig_DF)){
  Brigade_Single = Vic_Brig_DF[i,]
  Speed_Single = Brigade_Speed_DF %>% filter(Brigade == Brigade_Single$`Brigade Number`)
  if(nrow(Speed_Single) == 0){
    Brig_Environment = Brigade_Single$`Brigade Environment`
    Average_Speed = c(Average_Speed, mean((Brigade_Speed_DF %>% filter(ENvironment == Brig_Environment))$Average_Speed, na.rm = TRUE))
  }else if(is.na(Speed_Single$Average_Speed)){
    Brig_Environment = Brigade_Single$`Brigade Environment`
    Average_Speed = c(Average_Speed, mean((Brigade_Speed_DF %>% filter(ENvironment == Brig_Environment))$Average_Speed, na.rm = TRUE))
  }else{
    Average_Speed = c(Average_Speed, Speed_Single$Average_Speed)
  }
}


Vic_Brig_DF$Average_Speed = Average_Speed

F1 = FIRS %>% filter(brigade_no == 8117)

mean(F1$primary_sds_pass == "Y")





