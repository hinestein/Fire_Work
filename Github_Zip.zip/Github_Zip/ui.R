options(shiny.sanitize.errors = TRUE)

library("shiny")
library("bslib")
library("httr")
library("xml2")
library("readxl")
library("dplyr")
library("reshape2")
library("sf")
library("ggplot2")
library("shinydashboard")
library("RColorBrewer")
library("shinyjs")
library("scales")
library("leaflet")
library("geosphere")
library("shinyWidgets")
library("rsconnect")

page_fluid(
  # App title ----
  title = "Service Delivery App Test",
  # Sidebar panel for inputs ----
  layout_columns(
    layout_columns(
      card(
        card_header("Location Inputs"),
        # Input: Dropdown menu for Region
        selectizeInput(inputId ="Region",
                    label = "Region",
                    choices = NULL,
                    selected = ""
        ),
        
        
        
        
        selectizeInput(inputId = "District",
                    label = "District",
                    choices = NULL,
                    selected = ""),
        
        selectizeInput(
                       inputId = "Brigade",
                       label = "Brigade",
                       choices = NULL,
                       selected = ""),
        # Input: Reset Location Action Button
        actionButton(inputId = "reset_Location_input",
                     label = "Reset Location inputs")
        
      ),
      
      card(card_header("Scenario Inputs"),
           selectizeInput(inputId = "Year",
                       label = "Year",
                       choices = Years),
           selectizeInput(inputId = "LandUse",
                       label = "Land Use",
                       choices = c("Grassfire", "Bushfire"),
                       selected = NULL
           ),
           
           # Input: Slider bar for Population
           sliderInput(
             inputId = "Population",
             label = "Population",
             min = 0,
             max = 100000,
             value = 0
           ),
           numericInput(
             inputId = "Density",
             label = "Density",
             min = 0,
             max = 100,
             value = 0,
             step = 0.01
           ),
           sliderInput(
             inputId = "Incidents",
             label = "Incidents",
             min = 0,
             max = 60,
             value = 0
           ),
           actionButton(inputId = "reset_input",
                        label = "Reset Scenario inputs")
      ),
      col_widths = c(12, 12)
      
    ),
    layout_columns(
      card(radioButtons(inputId = "MapType",
                        label = "Level",
                        choices = c("Region", "District", "Brigade"),
                        inline = TRUE),
           checkboxInput(inputId = "Focus",
                         label = "Focused",
                         value = FALSE),
           navset_tab(
             nav_panel("Base Map",
                       leafletOutput(outputId = "mapPlot")
             ),
             nav_panel("Satellite Map",
                       leafletOutput(outputId = "SatellitemapPlot")
             ),
             nav_panel("Time Series",
                       leafletOutput(outputId = "TimeSeries")
             )
           ),
           conditionalPanel(
             condition = "input.Focus != true",
             selectizeInput(inputId = "MapFeatures",
                         label = "Feature",
                         choices = c("Choose Feature",
                                     "Member Locations",
                                     "Asset Status",
                                     "Brigade Environment",
                                     "Population",
                                     "Member Numbers"),
                         selected = "Choose Feature"
             )
           ),
           conditionalPanel(
             condition = "input.Focus == true & input.MapType == 'Brigade' & input.MapFeaturesFocus == 'SDS'",
            fluidRow(
              column(6, checkboxInput(inputId = "Incidents_SDS",
                                      label = "Incidents",
                                      value = FALSE),
                     checkboxInput(inputId = "FRV",
                                   label = "FRV Response",
                                   value = FALSE),
                     checkboxInput(inputId = "FRVDistrict",
                                   label = "FRV District",
                                   value = FALSE)
                     ),
                          column(6, numericInput(inputId="Neighbours",
                                                 label = "Neighbours",
                                                 value = 0,
                                                 min = 1,
                                                 max = 20),
                                 actionButton(inputId = "MarkerRemove",
                                              label = "Remove Custom Marker")
                          )
              )
           ),
           
           conditionalPanel(
             condition = "input.Focus == true",
             selectizeInput(inputId = "MapFeaturesFocus",
                         label = "Feature",
                         choices = c("Choose Feature",
                                     "Member Locations",
                                     "SDS"),
                         selected = "Choose Feature"
             )
           ),
           
           
      ),
      navset_tab(
        nav_panel("Region", layout_columns(
          card(card_header("Characteristics"),
               tableOutput(outputId = "RegionCharacteristics")),
          card(card_header("Assessment"),
               tableOutput(outputId = "RegionAssessment")))), 
        nav_panel("District", layout_columns(
          card(card_header("Characteristics"),
               tableOutput(outputId = "DistrictCharacteristics")),
          card(card_header("Assessment"),
               tableOutput(outputId = "DistrictAssessment")))), 
        nav_panel("Brigade", layout_columns(
          card(card_header("Characteristics"),
               tableOutput(outputId = "BrigadeCharacteristics")),
          card(card_header("Assessment"),
               tableOutput(outputId = "BrigadeAssessment")))),
        selected = "Brigade"
      ),
      card(card_header("CFA Overview"),
           tableOutput(outputId = "CFAOverview")),
      col_widths = c(12, 12, 12)
    ),
    
    layout_columns(
      card(card_header("Current Assets"),
           navset_tab(
             nav_panel("Brigade",
                       tableOutput(outputId = "Current")),
             nav_panel("District",
                       tableOutput(outputId = "DistrictAssets"))
           )
      ),
      card(card_header("Expected Assets"),
           tableOutput(outputId = "Expected")),
      card(card_header("Forecast Assets"),
           tableOutput(outputId = "Forecast")),
      card(card_header("Scenario Assets"),
           tableOutput(outputId = "Scenario")),
      col_widths = c(12, 12, 12, 12)
    ),
    col_widths = c(3, 6, 3)
  )
)